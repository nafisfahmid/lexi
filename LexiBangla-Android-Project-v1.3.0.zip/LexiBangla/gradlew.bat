@echo off
setlocal EnableExtensions EnableDelayedExpansion
set VERSION=8.13
if "%GRADLE_USER_HOME%"=="" set GRADLE_USER_HOME=%USERPROFILE%\.gradle
set BASE=%GRADLE_USER_HOME%\manual-wrapper
set INSTALL=%BASE%\gradle-%VERSION%
set GRADLE=%INSTALL%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE%" (
  if not exist "%BASE%" mkdir "%BASE%"
  set ARCHIVE=%BASE%\gradle-%VERSION%-bin.zip
  if not exist "!ARCHIVE!" (
    echo Downloading Gradle %VERSION%...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '!ARCHIVE!'"
    if errorlevel 1 exit /b 1
  )
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '!ARCHIVE!' '%INSTALL%'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE%" %*
endlocal
