@echo off
setlocal
if not exist gradle\wrapper\gradle-wrapper.jar (
  where gradle >nul 2>nul
  if errorlevel 1 (
    echo Gradle 8.13 is required. Install Gradle, then run: gradle wrapper --gradle-version 8.13
    exit /b 2
  )
  gradle wrapper --gradle-version 8.13
  if errorlevel 1 exit /b %errorlevel%
)
gradlew.bat assembleDebug
if errorlevel 1 exit /b %errorlevel%
if exist app\build\outputs\apk\debug\app-debug.apk (
  echo APK created: app\build\outputs\apk\debug\app-debug.apk
) else (
  echo Build completed but APK was not found.
  exit /b 3
)
endlocal
