# LexiBangla — Android vocabulary & writing app

LexiBangla is a native Android app for collecting English words with Bangla meanings, then practising and using those words in your own writing.

## Features (version 1.3.0)

- **Personal English–Bangla dictionary:** add and edit English words, Bangla Unicode meanings, simple English definitions, pronunciation, part of speech, examples, synonyms, topics, and personal notes.
- **Search and favourites:** search English, বাংলা, categories, and synonyms; star words you want to find quickly.
- **Flashcard review:** reveal the Bangla meaning, mark whether you remembered it, and let the app schedule the next review (1, 3, 7, 14, or 30 days as confidence improves).
- **Four-choice quiz:** alternating English-to-Bangla and Bangla-to-English questions generated from your own saved words, with instant answer feedback and a score. Requires at least four saved words.
- **IELTS / Academic starter pack:** optionally add 24 useful academic words with Bangla meanings, pronunciation guides, example sentences, and synonyms. You can edit every entry like your own words.
- **Daily word goal:** choose a goal of 3, 5, 10, or 15 new words; the home screen tracks how many you added today. The selected goal is included in backups.
- **Synonym practice:** synonyms appear on vocabulary cards and are searchable from your dictionary; use the “With synonyms” filter to browse them.
- **Collocations and idioms library:** includes 31 offline starter expressions (such as “make a decision”, “bear in mind”, and “break the ice”), with English definitions, Bangla meanings, examples, categories, and spaced review. Add your own expressions and practise by revealing meanings before marking recall.
- **Tap-to-hear pronunciation:** speaker icons use Android text-to-speech for English words. Voice quality and availability depend on the speech engine and English voice installed on the phone.
- **Word of the day:** a daily pick from your own saved vocabulary.
- **Writing studio:** practise individual sentences or longer paragraphs with a target word from your collection, prompts, and insertable linking expressions. See word count, unique-word count, sentence count, target-word use, and basic structure checks.
- **Offline grammar hints:** detects a curated set of common learner errors (for example, “I am agree”, “discuss about”, subject–verb patterns, repeated words, spacing, capitalisation and punctuation) and suggests revisions. It is a small rule-based helper, not a full grammar checker.
- **IELTS Academic Writing practice:** dedicated Task 1 and Task 2 modes with sample prompts, writing structures, Task 1 overview/data checks, Task 2 position/conclusion/paragraph checks, and 150/250-word targets. The app does not generate or claim an official IELTS band score.
- **Writing notebook:** save your practice sentences and paragraphs for later review; each entry is labelled by type.
- **Personal learning insights:** see vocabulary mastery levels, due reviews, words repeatedly forgotten, phrases needing practice, and writing activity. Writing trends compare the earliest and latest saved samples (up to five per group) using unique-word ratio and average words per sentence. These are descriptive indicators, not grammar corrections or official IELTS scores.
- **Backup and restore:** export your words and writing entries to a JSON file, or restore them on another device.
- **Offline-first storage:** entries are stored locally on the device. No account or internet connection is required for normal use.

## Open in Android Studio

1. Install a recent Android Studio release with the Android SDK Platform 36 and JDK 17.
2. Extract this folder and open the **LexiBangla** project directory in Android Studio.
3. Allow Gradle to sync and download the pinned dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Select the `app` run configuration and press **Run**.

**Gradle wrapper note:** this source archive does not contain the binary `gradle-wrapper.jar`. If Android Studio reports `GradleWrapperMain` missing, install Gradle 8.13 locally, run `gradle wrapper --gradle-version 8.13` from the project root to generate the standard wrapper files, or configure Android Studio to use that local Gradle 8.13 installation.

For a guided build checklist, see [BUILD_APK.md](BUILD_APK.md). Helper scripts are included as `build-apk.sh` (macOS/Linux) and `build-apk.bat` (Windows).

To build a debug APK from a terminal after the wrapper is generated, run:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Bangla input

The Bangla meaning field accepts ordinary Unicode text. Use a Bangla keyboard (for example, Gboard Bangla) or paste text into the field. The app does not transliterate English into Bangla; it stores the Bangla meaning you enter.

## Data and backup notes

- Words, collocations/idioms, review history, and writing entries stay in the app's private local storage.
- Export a backup from the top-right menu before moving to a new phone or reinstalling the app.
- Restoring a version 1.2 backup replaces the current local words, phrases, and writing samples with the backup contents. Older 1.0/1.1 backups restore words and writings while retaining the local phrase library.
- The JSON backup is UTF-8 and keeps Bangla Unicode characters intact.

## Version 1.3.0 notes

- Adds offline, rule-based language suggestions while writing. Feedback is limited to a curated list of common learner errors and proofreading checks; it is not a complete grammar engine.
- Adds IELTS Academic Writing Task 1 and Task 2 practice with rotating prompts and guidance on structure.
- Adds practical completion checks for word count, overview, numerical comparisons, position, conclusion and paragraph count. These are not official IELTS scoring criteria and do not produce a band estimate.
- Existing writing entries remain compatible. IELTS drafts save in the existing writing notebook with their task type, and all earlier backups remain importable.

## Version 1.2.0 notes

- Existing version 1.0 and 1.1 backups remain importable. New backups include English definitions, forgotten-word counts, phrase library entries, phrase review history, daily goal, and writing-entry type.
- Older word entries will show an empty English-definition field until you add a definition; the app does not invent one.
- The 31-item collocation and idiom starter library is initialized locally on first launch of this version. Custom phrases and review progress are included in backups.
- Word and phrase review history records how often an item was reviewed and forgotten. Low-mastery items with review history appear in the weak-word list.
- All new tools work offline and do not send your words or writing to a server.
- The academic starter pack remains optional; it is added only when you tap its home-screen action. Its 24 entries now include simple English definitions. Existing words with matching English spellings are not duplicated.

## Build verification

The offline grammar-feedback engine passes standalone Kotlin compilation and focused behavior checks. The existing academic and phrase starter packs remain unchanged. A full Android APK build and device test have not been performed in this environment because the Android SDK, Gradle installation, Gradle wrapper JAR and network access to download build dependencies are unavailable.

## Project details

- Kotlin + Jetpack Compose + Material 3
- Minimum Android version: Android 8.0 (API 26)
- Compile/target SDK: 36
- Release: 1.3.0 (versionCode 4)
- Package: `com.lexibangla.app`
