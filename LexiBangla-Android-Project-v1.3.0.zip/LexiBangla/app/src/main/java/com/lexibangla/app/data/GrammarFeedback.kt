package com.lexibangla.app.data

/**
 * Lightweight, offline writing hints. This intentionally avoids claiming to be a full grammar
 * checker: it looks for a small set of common learner errors and gives revision suggestions.
 */
data class GrammarTip(
    val title: String,
    val explanation: String,
    val suggestion: String,
    val category: String = "Grammar"
)

object GrammarFeedback {
    private data class Rule(
        val pattern: Regex,
        val title: String,
        val explanation: String,
        val suggestion: (MatchResult) -> String,
        val category: String = "Grammar"
    )

    private val rules = listOf(
        Rule(Regex("\\bI am agree\\b", RegexOption.IGNORE_CASE), "Use the verb ‘agree’ directly", "‘Agree’ is already a verb, so it does not need ‘am’.", { "I agree" }),
        Rule(Regex("\\bdiscuss about\\b", RegexOption.IGNORE_CASE), "Remove ‘about’ after ‘discuss’", "‘Discuss’ takes its topic directly as an object.", { "discuss the topic" }),
        Rule(Regex("\\bdespite of\\b", RegexOption.IGNORE_CASE), "Use ‘despite’ without ‘of’", "Use ‘despite the fact that’ when a full clause follows.", { "despite the rain / despite the fact that it rained" }),
        Rule(Regex("\\bmore better\\b", RegexOption.IGNORE_CASE), "Avoid a double comparative", "‘Better’ is already the comparative form of ‘good’.", { "better" }),
        Rule(Regex("\\bpeople is\\b", RegexOption.IGNORE_CASE), "‘People’ takes a plural verb", "Use ‘are’ or ‘were’ with ‘people’.", { "people are" }),
        Rule(Regex("\\bchildren is\\b", RegexOption.IGNORE_CASE), "‘Children’ takes a plural verb", "‘Children’ is plural, so use ‘are’ or ‘were’.", { "children are" }),
        Rule(Regex("\\bthey is\\b", RegexOption.IGNORE_CASE), "Check subject–verb agreement", "Use ‘are’ with ‘they’.", { "they are" }),
        Rule(Regex("\\bhe go\\b|\\bshe go\\b|\\bit go\\b", RegexOption.IGNORE_CASE), "Check the present-simple verb ending", "In the present simple, he/she/it usually takes an -s ending.", { match -> match.value.replace(Regex("\\bgo\\b", RegexOption.IGNORE_CASE), "goes") }),
        Rule(Regex("\\bdidn't went\\b|\\bdid not went\\b", RegexOption.IGNORE_CASE), "Use the base verb after ‘did’", "The past tense is already carried by ‘did’.", { match -> if (match.value.contains("not", true)) "did not go" else "didn't go" }),
        Rule(Regex("\\bdoesn't goes\\b|\\bdoes not goes\\b", RegexOption.IGNORE_CASE), "Use the base verb after ‘does’", "The -s ending belongs to ‘does’, not the main verb.", { match -> if (match.value.contains("not", true)) "does not go" else "doesn't go" }),
        Rule(Regex("\\b(can|could|will|would|should|must)\\s+to\\s+([a-z]+)\\b", RegexOption.IGNORE_CASE), "Use the base verb after a modal", "Modal verbs such as can, should and must are followed by the base verb without ‘to’.", { match -> "${match.groupValues[1]} ${match.groupValues[2]}" }),
        Rule(Regex("\\b(informations|advices|homeworks|furnitures)\\b", RegexOption.IGNORE_CASE), "Check this uncountable noun", "In standard English, this noun is generally uncountable and does not take a plural -s.", { match -> match.value.removeSuffix("s") }),
        Rule(Regex("\\b(very unique|more unique)\\b", RegexOption.IGNORE_CASE), "Consider a more precise expression", "‘Unique’ is usually treated as an absolute adjective. Choose a more specific description if you need emphasis.", { "truly unique / particularly unusual" }, "Style")
    )

    fun analyse(text: String): List<GrammarTip> {
        if (text.isBlank()) return emptyList()
        val tips = mutableListOf<GrammarTip>()
        rules.forEach { rule ->
            rule.pattern.find(text)?.let { match ->
                tips += GrammarTip(
                    title = rule.title,
                    explanation = rule.explanation,
                    suggestion = "Try: ${rule.suggestion(match)}",
                    category = rule.category
                )
            }
        }

        val repeated = Regex("\\b([A-Za-z]+)\\s+\\1\\b", RegexOption.IGNORE_CASE).find(text)
        if (repeated != null) {
            tips += GrammarTip(
                title = "Repeated word",
                explanation = "The same word appears twice in a row. This may be a typing mistake.",
                suggestion = "Review: ‘${repeated.value}’",
                category = "Proofreading"
            )
        }
        if (Regex(" {2,}").containsMatchIn(text)) {
            tips += GrammarTip(
                title = "Extra spaces",
                explanation = "There are two or more spaces together.",
                suggestion = "Keep a single space between words.",
                category = "Proofreading"
            )
        }
        val first = text.firstOrNull { !it.isWhitespace() }
        if (first != null && first.isLowerCase()) {
            tips += GrammarTip(
                title = "Capital letter at the beginning",
                explanation = "Start a sentence with a capital letter.",
                suggestion = "Capitalise the first word.",
                category = "Punctuation"
            )
        }
        val last = text.trimEnd().lastOrNull()
        if (last != null && last !in listOf('.', '!', '?', '”', '’', '"', '\'')) {
            tips += GrammarTip(
                title = "Add ending punctuation",
                explanation = "A complete sentence or paragraph normally ends with punctuation.",
                suggestion = "Add a full stop, question mark or exclamation mark where appropriate.",
                category = "Punctuation"
            )
        }
        val longSentence = text.split(Regex("(?<=[.!?])\\s+")).firstOrNull {
            Regex("[A-Za-z']+").findAll(it).count() > 35
        }
        if (longSentence != null) {
            tips += GrammarTip(
                title = "Review a long sentence",
                explanation = "This sentence has more than 35 words. Long sentences can become difficult to follow.",
                suggestion = "Check whether it would be clearer as two shorter sentences.",
                category = "Clarity"
            )
        }
        return tips.distinctBy { it.title }.take(8)
    }
}
