package com.lexibangla.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.lexibangla.app.data.WordRepository
import com.lexibangla.app.ui.LexiBanglaApp
import com.lexibangla.app.ui.theme.LexiBanglaTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val repository = WordRepository(applicationContext)
        setContent {
            LexiBanglaTheme {
                LexiBanglaApp(repository = repository)
            }
        }
    }
}
