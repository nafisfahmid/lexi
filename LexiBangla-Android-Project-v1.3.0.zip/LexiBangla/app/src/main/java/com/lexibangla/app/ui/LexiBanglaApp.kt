package com.lexibangla.app.ui

import android.widget.Toast
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.lexibangla.app.data.Word
import com.lexibangla.app.data.Phrase
import com.lexibangla.app.data.WordRepository
import com.lexibangla.app.data.AcademicWordPack
import com.lexibangla.app.data.GrammarFeedback
import com.lexibangla.app.data.WritingEntry
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.time.Instant
import java.time.ZoneId
import java.time.LocalDate

private enum class AppTab(val label: String) {
    Home("Home"), Words("Words"), Practice("Practice"), Writing("Writing")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LexiBanglaApp(repository: WordRepository) {
    val context = LocalContext.current
    val speechRef = remember { java.util.concurrent.atomic.AtomicReference<TextToSpeech?>(null) }
    val speechEngine = remember(context) {
        TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) speechRef.get()?.language = Locale.US
        }.also { speechRef.set(it) }
    }
    DisposableEffect(speechEngine) {
        onDispose { speechEngine.stop(); speechEngine.shutdown(); speechRef.set(null) }
    }
    fun speakWord(text: String) {
        if (text.isNotBlank()) speechEngine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "lexibangla-${System.currentTimeMillis()}")
    }
    var words by remember { mutableStateOf(repository.loadWords()) }
    var phrases by remember { mutableStateOf(repository.loadPhrases()) }
    var writings by remember { mutableStateOf(repository.loadWritingEntries()) }
    var dailyGoal by remember { mutableIntStateOf(repository.loadDailyGoal()) }
    var selectedTab by remember { mutableStateOf(AppTab.Home) }
    var editorVisible by remember { mutableStateOf(false) }
    var editorSeed by remember { mutableStateOf<Word?>(null) }
    var menuExpanded by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.use { output ->
                    output.write(repository.exportBackup().toByteArray(Charsets.UTF_8))
                }
                Toast.makeText(context, "Backup exported successfully", Toast.LENGTH_SHORT).show()
            } catch (_: Exception) {
                Toast.makeText(context, "Could not export backup", Toast.LENGTH_LONG).show()
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val backupText = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (repository.importBackup(backupText)) {
                    words = repository.loadWords()
                    writings = repository.loadWritingEntries()
                    phrases = repository.loadPhrases()
                    Toast.makeText(context, "Backup restored", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "That backup file is not valid", Toast.LENGTH_LONG).show()
                }
            } catch (_: Exception) {
                Toast.makeText(context, "Could not read backup file", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun openEditor(word: Word?) {
        editorSeed = word
        editorVisible = true
    }

    fun saveWord(word: Word) {
        val exists = words.any { it.id == word.id }
        words = if (exists) words.map { if (it.id == word.id) word else it }
        else listOf(word) + words
        repository.saveWords(words)
        editorVisible = false
        Toast.makeText(context, if (exists) "Word updated" else "Word added to your collection", Toast.LENGTH_SHORT).show()
    }

    fun updateWord(word: Word) {
        words = words.map { if (it.id == word.id) word else it }
        repository.saveWords(words)
    }

    fun saveWriting(entry: WritingEntry) {
        writings = listOf(entry) + writings
        repository.saveWritingEntries(writings)
        Toast.makeText(context, "Writing saved", Toast.LENGTH_SHORT).show()
    }

    fun savePhrase(phrase: Phrase) {
        val exists = phrases.any { it.phrase.equals(phrase.phrase, ignoreCase = true) }
        if (exists) {
            Toast.makeText(context, "That phrase is already in your library", Toast.LENGTH_SHORT).show()
            return
        }
        phrases = listOf(phrase) + phrases
        repository.savePhrases(phrases)
        Toast.makeText(context, "Phrase added to your library", Toast.LENGTH_SHORT).show()
    }

    fun updatePhrase(phrase: Phrase, remembered: Boolean) {
        val newMastery = if (remembered) (phrase.mastery + 1).coerceAtMost(5) else 0
        val delayDays = when {
            !remembered -> 1L
            newMastery <= 1 -> 1L
            newMastery == 2 -> 3L
            newMastery == 3 -> 7L
            newMastery == 4 -> 14L
            else -> 30L
        }
        phrases = phrases.map {
            if (it.id == phrase.id) it.copy(
                mastery = newMastery,
                reviewCount = it.reviewCount + 1,
                forgottenCount = it.forgottenCount + if (remembered) 0 else 1,
                nextReviewAt = System.currentTimeMillis() + delayDays * 24L * 60L * 60L * 1000L
            ) else it
        }
        repository.savePhrases(phrases)
    }

    val title = when (selectedTab) {
        AppTab.Home -> "LexiBangla"
        AppTab.Words -> "My vocabulary"
        AppTab.Practice -> "Daily practice"
        AppTab.Writing -> "Writing studio"
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, fontWeight = FontWeight.Bold)
                        if (selectedTab == AppTab.Home) {
                            Text("Your personal English word garden", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { menuExpanded = true }) {
                        Icon(Icons.Default.MoreVert, contentDescription = "More options")
                    }
                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                        DropdownMenuItem(
                            text = { Text("Export backup") },
                            leadingIcon = { Icon(Icons.Default.FileDownload, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                exportLauncher.launch("lexibangla-backup.json")
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Restore backup") },
                            leadingIcon = { Icon(Icons.Default.FileUpload, contentDescription = null) },
                            onClick = {
                                menuExpanded = false
                                importLauncher.launch(arrayOf("application/json", "text/*"))
                            }
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                AppTab.values().forEach { tab ->
                    val icon = when (tab) {
                        AppTab.Home -> Icons.Default.Home
                        AppTab.Words -> Icons.Default.MenuBook
                        AppTab.Practice -> Icons.Default.School
                        AppTab.Writing -> Icons.Default.Edit
                    }
                    NavigationBarItem(
                        selected = selectedTab == tab,
                        onClick = { selectedTab = tab },
                        icon = { Icon(icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (selectedTab == AppTab.Words) {
                FloatingActionButton(onClick = { openEditor(null) }) {
                    Icon(Icons.Default.Add, contentDescription = "Add word")
                }
            }
        }
    ) { innerPadding ->
        Box(Modifier.fillMaxSize().padding(innerPadding)) {
            when (selectedTab) {
                AppTab.Home -> HomeScreen(
                    words = words,
                    writingCount = writings.size,
                    onSpeakWord = ::speakWord,
                    dailyGoal = dailyGoal,
                    onDailyGoalChange = { goal -> dailyGoal = goal; repository.saveDailyGoal(goal) },
                    onImportAcademicPack = {
                        val existing = words.map { it.english.lowercase() }.toSet()
                        val additions = AcademicWordPack.words.filterNot { it.english.lowercase() in existing }
                        words = additions + words
                        repository.saveWords(words)
                        Toast.makeText(context, if (additions.isEmpty()) "Academic pack is already in your vocabulary" else "Added ${additions.size} academic words", Toast.LENGTH_LONG).show()
                    },
                    onAddWord = { openEditor(null) },
                    onPractice = { selectedTab = AppTab.Practice },
                    onWrite = { selectedTab = AppTab.Writing },
                    onEditWord = { openEditor(it) }
                )
                AppTab.Words -> WordsScreen(
                    words = words,
                    onSpeakWord = ::speakWord,
                    onEdit = { openEditor(it) },
                    onFavorite = { updateWord(it.copy(favorite = !it.favorite)) },
                    onDelete = { word ->
                        words = words.filterNot { it.id == word.id }
                        repository.saveWords(words)
                        Toast.makeText(context, "Word deleted", Toast.LENGTH_SHORT).show()
                    }
                )
                AppTab.Practice -> PracticeScreen(
                    words = words,
                    phrases = phrases,
                    writings = writings,
                    onSpeakWord = ::speakWord,
                    onReview = { word, remembered ->
                        val newMastery = if (remembered) (word.mastery + 1).coerceAtMost(5) else 0
                        val delayDays = when {
                            !remembered -> 1L
                            newMastery <= 1 -> 1L
                            newMastery == 2 -> 3L
                            newMastery == 3 -> 7L
                            newMastery == 4 -> 14L
                            else -> 30L
                        }
                        updateWord(word.copy(
                            mastery = newMastery,
                            reviewCount = word.reviewCount + 1,
                            forgottenCount = word.forgottenCount + if (remembered) 0 else 1,
                            nextReviewAt = System.currentTimeMillis() + delayDays * 24L * 60L * 60L * 1000L
                        ))
                    },
                    onGoToWords = { selectedTab = AppTab.Words },
                    onReviewPhrase = ::updatePhrase,
                    onSavePhrase = ::savePhrase
                )
                AppTab.Writing -> WritingScreen(
                    words = words,
                    onSpeakWord = ::speakWord,
                    entries = writings,
                    onSave = ::saveWriting
                )
            }
        }
    }

    if (editorVisible) {
        WordEditorDialog(
            initial = editorSeed,
            onDismiss = { editorVisible = false },
            onSave = ::saveWord
        )
    }
}

@Composable
private fun HomeScreen(
    words: List<Word>,
    writingCount: Int,
    onSpeakWord: (String) -> Unit,
    dailyGoal: Int,
    onDailyGoalChange: (Int) -> Unit,
    onImportAcademicPack: () -> Unit,
    onAddWord: () -> Unit,
    onPractice: () -> Unit,
    onWrite: () -> Unit,
    onEditWord: (Word) -> Unit
) {
    val now = System.currentTimeMillis()
    val dueCount = words.count { it.nextReviewAt <= now }
    val masteredCount = words.count { it.mastery >= 4 }
    val dailyWord = if (words.isNotEmpty()) {
        val index = (java.time.LocalDate.now().toEpochDay() % words.size).toInt()
        words.sortedBy { it.english.lowercase() }.getOrNull(index)
    } else null

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Small words. Stronger expression.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Collect the words you meet, understand them in Bangla, and make them part of your English.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard(value = words.size.toString(), label = "Words saved", modifier = Modifier.weight(1f), icon = "📚")
            StatCard(value = dueCount.toString(), label = "Due to review", modifier = Modifier.weight(1f), icon = "🔁")
            StatCard(value = writingCount.toString(), label = "Writings", modifier = Modifier.weight(1f), icon = "✍️")
        }

        val today = LocalDate.now()
        val addedToday = words.count { Instant.ofEpochMilli(it.createdAt).atZone(ZoneId.systemDefault()).toLocalDate() == today }
        ElevatedCard(shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Daily word goal", fontWeight = FontWeight.Bold)
                        Text("$addedToday of $dailyGoal new words added today", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    SmallPill(if (addedToday >= dailyGoal) "Goal reached ✓" else "Keep going")
                }
                LinearProgressIndicator(progress = { (addedToday.toFloat() / dailyGoal).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Daily target", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    listOf(3, 5, 10, 15).forEach { value ->
                        FilterChip(selected = dailyGoal == value, onClick = { onDailyGoalChange(value) }, label = { Text(value.toString()) })
                    }
                }
            }
        }

        if (dailyWord != null) {
            ElevatedCard(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(8.dp))
                        Text("WORD OF THE DAY", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(dailyWord.english, modifier = Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        IconButton(onClick = { onSpeakWord(dailyWord.english) }) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear pronunciation", tint = MaterialTheme.colorScheme.primary) }
                    }
                    Text(dailyWord.bangla, fontSize = 22.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (dailyWord.englishDefinition.isNotBlank()) Text(dailyWord.englishDefinition, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (dailyWord.example.isNotBlank()) Text(dailyWord.example, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { onEditWord(dailyWord) }) {
                            Text("Open word")
                            Spacer(Modifier.width(4.dp))
                            Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        } else {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Your word garden starts here", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text("Add your first English word and its Bangla meaning. You can add examples, synonyms, and notes too.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = onAddWord) {
                        Icon(Icons.Default.Add, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Add your first word")
                    }
                }
            }
        }

        Text("Make progress today", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionCard("Add a word", "Save a new discovery", "＋", Modifier.weight(1f), onAddWord)
            QuickActionCard("Review", "Recall what you know", "↻", Modifier.weight(1f), onPractice)
        }
        QuickActionCard("Writing studio", "Practise sentences and paragraphs", "✍", Modifier.fillMaxWidth(), onWrite)
        QuickActionCard("IELTS / Academic pack", "Add 24 useful academic words with Bangla meanings", "A+", Modifier.fillMaxWidth(), onImportAcademicPack)

        if (words.isNotEmpty()) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Recently added", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Text("${masteredCount} mastered", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            }
            words.sortedByDescending { it.createdAt }.take(3).forEach { word ->
                WordRowCard(word = word, onClick = { onEditWord(word) }, onSpeakWord = { onSpeakWord(word.english) })
            }
        }
    }
}

@Composable
private fun StatCard(value: String, label: String, modifier: Modifier = Modifier, icon: String) {
    ElevatedCard(modifier = modifier, shape = RoundedCornerShape(18.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(icon, fontSize = 19.sp)
            Text(value, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
        }
    }
}

@Composable
private fun QuickActionCard(title: String, subtitle: String, symbol: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    ElevatedCard(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = CircleShape, color = MaterialTheme.colorScheme.secondaryContainer, modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(symbol, fontSize = 22.sp, color = MaterialTheme.colorScheme.onSecondaryContainer) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ArrowForward, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun WordsScreen(
    words: List<Word>,
    onSpeakWord: (String) -> Unit,
    onEdit: (Word) -> Unit,
    onFavorite: (Word) -> Unit,
    onDelete: (Word) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var favoritesOnly by remember { mutableStateOf(false) }
    var synonymsOnly by remember { mutableStateOf(false) }
    val filtered = words
        .filter { !favoritesOnly || it.favorite }
        .filter { !synonymsOnly || it.synonyms.isNotBlank() }
        .filter { word ->
            search.isBlank() || word.english.contains(search, ignoreCase = true) ||
                word.bangla.contains(search, ignoreCase = true) || word.englishDefinition.contains(search, ignoreCase = true) || word.category.contains(search, ignoreCase = true) ||
                word.synonyms.contains(search, ignoreCase = true)
        }
        .sortedBy { it.english.lowercase() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            placeholder = { Text("Search English, বাংলা, synonym...") },
            singleLine = true,
            shape = RoundedCornerShape(16.dp)
        )
        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = !favoritesOnly && !synonymsOnly,
                onClick = { favoritesOnly = false; synonymsOnly = false },
                label = { Text("All · ${words.size}") }
            )
            FilterChip(
                selected = favoritesOnly,
                onClick = { favoritesOnly = !favoritesOnly },
                label = { Text("Favorites · ${words.count { it.favorite }}") },
                leadingIcon = { Icon(Icons.Default.Favorite, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            FilterChip(
                selected = synonymsOnly,
                onClick = { synonymsOnly = !synonymsOnly },
                label = { Text("With synonyms · ${words.count { it.synonyms.isNotBlank() }}") }
            )
        }
        if (filtered.isEmpty()) {
            EmptyState(
                title = if (words.isEmpty()) "No words yet" else "No matching words",
                message = if (words.isEmpty()) "Tap the + button to save your first word with its Bangla meaning." else "Try another search or switch back to All words."
            )
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 92.dp)) {
                items(filtered, key = { it.id }) { word ->
                    VocabularyCard(
                        word = word,
                        onSpeakWord = { onSpeakWord(word.english) },
                        onEdit = { onEdit(word) },
                        onFavorite = { onFavorite(word) },
                        onDelete = { onDelete(word) }
                    )
                }
            }
        }
    }
}

@Composable
private fun VocabularyCard(word: Word, onSpeakWord: () -> Unit, onEdit: () -> Unit, onFavorite: () -> Unit, onDelete: () -> Unit) {
    var menuExpanded by remember(word.id) { mutableStateOf(false) }
    ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.Top) {
                Column(Modifier.weight(1f).clickable(onClick = onEdit), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(word.english, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    if (word.pronunciation.isNotBlank()) Text("/${word.pronunciation}/", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = onSpeakWord) {
                    Icon(Icons.Default.VolumeUp, contentDescription = "Hear pronunciation", tint = MaterialTheme.colorScheme.primary)
                }
                IconButton(onClick = onFavorite) {
                    Icon(if (word.favorite) Icons.Default.Star else Icons.Default.StarBorder, contentDescription = "Toggle favorite", tint = if (word.favorite) Color(0xFFE1A52C) else MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Box {
                    IconButton(onClick = { menuExpanded = true }) { Icon(Icons.Default.MoreVert, contentDescription = "Word options") }
                    DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                        DropdownMenuItem(text = { Text("Edit") }, leadingIcon = { Icon(Icons.Default.Edit, null) }, onClick = { menuExpanded = false; onEdit() })
                        DropdownMenuItem(text = { Text("Delete") }, leadingIcon = { Icon(Icons.Default.Delete, null) }, onClick = { menuExpanded = false; onDelete() })
                    }
                }
            }
            Text(word.bangla, fontSize = 21.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.primary)
            if (word.englishDefinition.isNotBlank()) Text(word.englishDefinition, style = MaterialTheme.typography.bodyMedium)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (word.partOfSpeech.isNotBlank()) SmallPill(word.partOfSpeech)
                SmallPill(word.category.ifBlank { "General" })
                SmallPill("Level ${word.mastery}/5")
            }
            if (word.example.isNotBlank()) Text(word.example, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            if (word.synonyms.isNotBlank()) Text("Similar: ${word.synonyms}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WordRowCard(word: Word, onClick: () -> Unit, onSpeakWord: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(word.english, fontWeight = FontWeight.SemiBold)
                Text(word.bangla, color = MaterialTheme.colorScheme.primary, fontSize = 17.sp)
                if (word.englishDefinition.isNotBlank()) Text(word.englishDefinition, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = onSpeakWord) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear pronunciation") }
            if (word.favorite) Icon(Icons.Default.Star, contentDescription = "Favorite", tint = Color(0xFFE1A52C))
        }
    }
}

private data class QuizQuestion(val correct: Word, val options: List<Word>, val askBangla: Boolean)

@Composable
private fun PracticeScreen(
    words: List<Word>,
    phrases: List<Phrase>,
    writings: List<WritingEntry>,
    onSpeakWord: (String) -> Unit,
    onReview: (Word, Boolean) -> Unit,
    onGoToWords: () -> Unit,
    onReviewPhrase: (Phrase, Boolean) -> Unit,
    onSavePhrase: (Phrase) -> Unit
) {
    var mode by remember { mutableStateOf("Flashcards") }
    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            listOf("Flashcards", "Quiz", "Phrases", "Insights").forEach { option ->
                FilterChip(selected = mode == option, onClick = { mode = option }, label = { Text(option) })
            }
        }
        Box(Modifier.weight(1f)) {
            when (mode) {
                "Flashcards" -> FlashcardScreen(words, onSpeakWord, onReview, onGoToWords)
                "Quiz" -> QuizScreen(words, onSpeakWord)
                "Phrases" -> PhraseLibraryScreen(phrases, onSpeakWord, onReviewPhrase, onSavePhrase)
                else -> InsightsScreen(words, phrases, writings)
            }
        }
    }
}

@Composable
private fun PhraseLibraryScreen(
    phrases: List<Phrase>,
    onSpeakWord: (String) -> Unit,
    onReview: (Phrase, Boolean) -> Unit,
    onSave: (Phrase) -> Unit
) {
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("All") }
    var editorVisible by remember { mutableStateOf(false) }
    val filtered = phrases.filter { phrase ->
        (filter == "All" || phrase.kind == filter) &&
            (search.isBlank() || phrase.phrase.contains(search, true) || phrase.englishDefinition.contains(search, true) ||
                phrase.bangla.contains(search, true) || phrase.category.contains(search, true))
    }.sortedBy { it.phrase.lowercase() }
    val dueCount = phrases.count { it.nextReviewAt <= System.currentTimeMillis() }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text("Collocations & idioms", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Learn natural word combinations and expressions.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { editorVisible = true }) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(5.dp)); Text("Add") }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(phrases.size.toString(), "Phrases", Modifier.weight(1f), "💬")
            StatCard(phrases.count { it.mastery >= 4 }.toString(), "Confident", Modifier.weight(1f), "⭐")
            StatCard(dueCount.toString(), "Ready to review", Modifier.weight(1f), "🔁")
        }
        OutlinedTextField(
            value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(),
            leadingIcon = { Icon(Icons.Default.Search, null) }, placeholder = { Text("Search phrase, meaning, বাংলা...") },
            singleLine = true, shape = RoundedCornerShape(15.dp)
        )
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("All", "Collocation", "Idiom").forEach { value ->
                FilterChip(selected = filter == value, onClick = { filter = value }, label = { Text(value) })
            }
        }
        if (filtered.isEmpty()) {
            EmptyState("No matching phrases", "Try another search, or add a phrase you want to remember.")
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(filtered, key = { it.id }) { phrase ->
                    PhraseCard(phrase, onSpeak = { onSpeakWord(phrase.phrase) }, onReview = onReview)
                }
            }
        }
    }
    if (editorVisible) {
        PhraseEditorDialog(
            onDismiss = { editorVisible = false },
            onSave = { onSave(it); editorVisible = false }
        )
    }
}

@Composable
private fun PhraseCard(phrase: Phrase, onSpeak: () -> Unit, onReview: (Phrase, Boolean) -> Unit) {
    var revealed by remember(phrase.id) { mutableStateOf(false) }
    ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(phrase.phrase, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SmallPill(phrase.kind)
                        SmallPill(phrase.category)
                        SmallPill("Level ${phrase.mastery}/5")
                    }
                }
                IconButton(onClick = onSpeak) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear phrase", tint = MaterialTheme.colorScheme.primary) }
            }
            if (revealed) {
                HorizontalDivider()
                Text(phrase.englishDefinition, style = MaterialTheme.typography.bodyMedium)
                Text(phrase.bangla, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                if (phrase.example.isNotBlank()) Text("Example: ${phrase.example}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("Reviews: ${phrase.reviewCount} · Forgot: ${phrase.forgottenCount}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { onReview(phrase, false); revealed = false }, modifier = Modifier.weight(1f)) { Text("Need practice") }
                    Button(onClick = { onReview(phrase, true); revealed = false }, modifier = Modifier.weight(1f)) { Text("I remembered") }
                }
            } else {
                Text("Try to explain this expression before revealing its meaning.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                OutlinedButton(onClick = { revealed = true }, modifier = Modifier.fillMaxWidth()) { Text("Reveal definition & Bangla") }
            }
        }
    }
}

@Composable
private fun PhraseEditorDialog(onDismiss: () -> Unit, onSave: (Phrase) -> Unit) {
    var phrase by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("Collocation") }
    var definition by remember { mutableStateOf("") }
    var bangla by remember { mutableStateOf("") }
    var example by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("My phrases") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add a phrase", fontWeight = FontWeight.Bold) },
        text = {
            Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = kind == "Collocation", onClick = { kind = "Collocation" }, label = { Text("Collocation") })
                    FilterChip(selected = kind == "Idiom", onClick = { kind = "Idiom" }, label = { Text("Idiom") })
                }
                OutlinedTextField(phrase, { phrase = it }, label = { Text("Phrase *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(definition, { definition = it }, label = { Text("English definition *") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(bangla, { bangla = it }, label = { Text("Bangla meaning") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(example, { example = it }, label = { Text("Example sentence") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(category, { category = it }, label = { Text("Topic") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = { onSave(Phrase(phrase = phrase.trim(), kind = kind, englishDefinition = definition.trim(), bangla = bangla.trim(), example = example.trim(), category = category.trim().ifBlank { "My phrases" })) }, enabled = phrase.isNotBlank() && definition.isNotBlank()) { Text("Save phrase") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private data class WritingMetrics(val lexicalDiversity: Double, val wordsPerSentence: Double)

private fun writingMetrics(entries: List<WritingEntry>): WritingMetrics? {
    if (entries.isEmpty()) return null
    val samples = entries.map { it.sentence }
    val tokens = samples.flatMap { Regex("[A-Za-z']+").findAll(it.lowercase()).map { match -> match.value }.toList() }
    if (tokens.isEmpty()) return null
    val sentences = samples.sumOf { text -> Regex("[.!?]+(?=\\s|$)").findAll(text).count().coerceAtLeast(1) }
    return WritingMetrics(
        lexicalDiversity = tokens.distinct().size.toDouble() / tokens.size.toDouble(),
        wordsPerSentence = tokens.size.toDouble() / sentences.coerceAtLeast(1)
    )
}

@Composable
private fun InsightsScreen(words: List<Word>, phrases: List<Phrase>, writings: List<WritingEntry>) {
    val now = System.currentTimeMillis()
    val dueWords = words.filter { it.nextReviewAt <= now }
    val weakWords = words.filter { (it.reviewCount > 0 && it.mastery <= 1) || (it.forgottenCount > 0 && it.mastery <= 2) }
        .sortedWith(compareByDescending<Word> { it.forgottenCount }.thenBy { it.mastery }.thenBy { it.nextReviewAt })
    val newlyAdded = words.count { it.reviewCount == 0 }
    val reviewedTotal = words.sumOf { it.reviewCount }
    val mastered = words.count { it.mastery >= 4 }
    val lastSevenDays = writings.count { now - it.createdAt <= 7L * 24L * 60L * 60L * 1000L }
    val writingWordTotal = writings.sumOf { Regex("[A-Za-z']+").findAll(it.sentence).count() }
    val chronological = writings.sortedBy { it.createdAt }
    val windowSize = (chronological.size / 2).coerceAtMost(5)
    val previousMetrics = if (windowSize > 0) writingMetrics(chronological.take(windowSize)) else null
    val latestMetrics = if (windowSize > 0) writingMetrics(chronological.takeLast(windowSize)) else null
    val diversityDelta = if (previousMetrics != null && latestMetrics != null) (latestMetrics.lexicalDiversity - previousMetrics.lexicalDiversity) * 100 else null
    val duePhrases = phrases.count { it.nextReviewAt <= now }
    val weakPhraseCount = phrases.count { (it.reviewCount > 0 && it.mastery <= 1) || (it.forgottenCount > 0 && it.mastery <= 2) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("Your learning insights", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("A practical view of what you know, what needs review, and how your writing is developing.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Text("VOCABULARY", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(words.size.toString(), "Words saved", Modifier.weight(1f), "📚")
            StatCard(dueWords.size.toString(), "Due now", Modifier.weight(1f), "🔁")
            StatCard(mastered.toString(), "Mastered", Modifier.weight(1f), "⭐")
        }
        ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Vocabulary strength", fontWeight = FontWeight.Bold)
                val groups = listOf(
                    Triple("Needs practice · 0–1", words.count { it.mastery <= 1 }, MaterialTheme.colorScheme.error),
                    Triple("Developing · 2–3", words.count { it.mastery in 2..3 }, MaterialTheme.colorScheme.tertiary),
                    Triple("Confident · 4–5", mastered, MaterialTheme.colorScheme.primary)
                )
                groups.forEach { (label, count, tint) ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(label, style = MaterialTheme.typography.bodySmall); Text(count.toString(), fontWeight = FontWeight.SemiBold) }
                    LinearProgressIndicator(progress = { if (words.isEmpty()) 0f else count.toFloat() / words.size }, modifier = Modifier.fillMaxWidth(), color = tint)
                }
                Text("$reviewedTotal total word reviews · $newlyAdded words have not been reviewed yet", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Text("WORDS TO REVISIT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        if (weakWords.isEmpty()) {
            Text("No weak words detected yet. Review more flashcards to build a useful learning history.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            weakWords.take(8).forEach { word ->
                Card(shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(word.english, fontWeight = FontWeight.SemiBold)
                            Text(word.bangla, color = MaterialTheme.colorScheme.primary)
                            Text("Remembered level ${word.mastery}/5 · forgotten ${word.forgottenCount} times", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (word.nextReviewAt <= now) SmallPill("Due")
                    }
                }
            }
        }
        Text("COLLOCATIONS & IDIOMS", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(phrases.size.toString(), "Saved phrases", Modifier.weight(1f), "💬")
            StatCard(duePhrases.toString(), "Phrase reviews due", Modifier.weight(1f), "🔁")
            StatCard(weakPhraseCount.toString(), "Need practice", Modifier.weight(1f), "🧠")
        }
        Text("WRITING DEVELOPMENT", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatCard(writings.size.toString(), "Saved samples", Modifier.weight(1f), "✍️")
            StatCard(writingWordTotal.toString(), "Words written", Modifier.weight(1f), "🔤")
            StatCard(lastSevenDays.toString(), "Last 7 days", Modifier.weight(1f), "📅")
        }
        ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Text("Writing trend indicators", fontWeight = FontWeight.Bold)
                if (previousMetrics != null && latestMetrics != null) {
                    val previousDiversity = "%.0f%%".format(Locale.getDefault(), previousMetrics.lexicalDiversity * 100)
                    val latestDiversity = "%.0f%%".format(Locale.getDefault(), latestMetrics.lexicalDiversity * 100)
                    val previousSentence = "%.1f".format(Locale.getDefault(), previousMetrics.wordsPerSentence)
                    val latestSentence = "%.1f".format(Locale.getDefault(), latestMetrics.wordsPerSentence)
                    Text("Unique-word ratio: $previousDiversity → $latestDiversity", fontWeight = FontWeight.Medium)
                    Text("Average words per sentence: $previousSentence → $latestSentence", fontWeight = FontWeight.Medium)
                    if (diversityDelta != null) {
                        val deltaText = (if (diversityDelta >= 0) "+" else "") + "%.1f percentage points".format(Locale.getDefault(), diversityDelta)
                        SmallPill("Vocabulary variety $deltaText")
                    }
                    Text("Compared the first ${windowSize} saved sample(s) with the latest ${windowSize}. These are descriptive indicators, not grammar or IELTS scores.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text("Save at least two writing samples to start comparing your vocabulary variety and sentence length over time.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Text("Tip: a higher unique-word ratio can show more varied vocabulary, but clarity and accuracy matter more than using as many different words as possible.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun QuizScreen(words: List<Word>, onSpeakWord: (String) -> Unit) {
    if (words.size < 4) {
        EmptyState(
            title = "Add at least 4 words for a quiz",
            message = "The quiz uses your own saved vocabulary and creates four-choice questions. Add a few more words to unlock it."
        )
        return
    }

    val wordIds = remember(words) { words.map { it.id } }
    val questions = remember(wordIds) {
        val shuffled = words.shuffled()
        shuffled.take(minOf(10, shuffled.size)).mapIndexed { index, correct ->
            val distractors = shuffled.filterNot { it.id == correct.id }.shuffled().take(3)
            QuizQuestion(correct, (distractors + correct).shuffled(), askBangla = index % 2 == 0)
        }
    }
    var questionIndex by remember(wordIds) { mutableIntStateOf(0) }
    var selectedId by remember(wordIds) { mutableStateOf<String?>(null) }
    var score by remember(wordIds) { mutableIntStateOf(0) }
    val question = questions.getOrNull(questionIndex)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Quick vocabulary quiz", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Alternate between English-to-Bangla and Bangla-to-English recall.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (question == null) {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("QUIZ COMPLETE", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("$score / ${questions.size}", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                    Text(when {
                        score == questions.size -> "Excellent recall. You knew every answer!"
                        score * 2 >= questions.size -> "Good work. Review the missed words and try again."
                        else -> "A useful practice round. Revisit your flashcards and give it another try."
                    }, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { questionIndex = 0; selectedId = null; score = 0 }) {
                        Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Restart quiz")
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                SmallPill(if (question.askBangla) "English → Bangla" else "Bangla → English")
                Text("${questionIndex + 1} / ${questions.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            LinearProgressIndicator(progress = { (questionIndex + 1f) / questions.size }, modifier = Modifier.fillMaxWidth())
            ElevatedCard(shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(22.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CHOOSE THE CORRECT MEANING", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (question.askBangla) question.correct.english else question.correct.bangla,
                            modifier = Modifier.weight(1f),
                            style = if (question.askBangla) MaterialTheme.typography.headlineMedium else MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (question.askBangla) IconButton(onClick = { onSpeakWord(question.correct.english) }) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear word") }
                    }
                }
            }
            question.options.forEach { option ->
                val isSelected = selectedId == option.id
                val isCorrect = option.id == question.correct.id
                val container = when {
                    selectedId == null -> MaterialTheme.colorScheme.surface
                    isCorrect -> MaterialTheme.colorScheme.primaryContainer
                    isSelected -> MaterialTheme.colorScheme.errorContainer
                    else -> MaterialTheme.colorScheme.surface
                }
                Card(
                    modifier = Modifier.fillMaxWidth().clickable(enabled = selectedId == null) {
                        selectedId = option.id
                        if (isCorrect) score++
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = container),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
                ) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (question.askBangla) option.bangla else option.english, modifier = Modifier.weight(1f), fontWeight = FontWeight.Medium, fontSize = if (question.askBangla) 19.sp else 17.sp)
                        if (selectedId != null && isCorrect) Icon(Icons.Default.CheckCircle, null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
            if (selectedId != null) {
                val gotItRight = selectedId == question.correct.id
                Text(if (gotItRight) "Correct! ${question.correct.english} means ${question.correct.bangla}." else "Not quite. The answer is ${question.correct.english} — ${question.correct.bangla}.", color = if (gotItRight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
                Button(onClick = { questionIndex++; selectedId = null }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (questionIndex == questions.lastIndex) "See results" else "Next question")
                    Spacer(Modifier.width(8.dp)); Icon(Icons.Default.ArrowForward, null)
                }
            }
        }
    }
}

@Composable
private fun FlashcardScreen(words: List<Word>, onSpeakWord: (String) -> Unit, onReview: (Word, Boolean) -> Unit, onGoToWords: () -> Unit) {
    if (words.isEmpty()) {
        EmptyState(
            title = "Your first flashcard is waiting",
            message = "Add a few words to your vocabulary and come back here to practise them.",
            actionLabel = "Add words",
            onAction = onGoToWords
        )
        return
    }

    // Keep the session queue stable while review dates are updated during this session.
    val wordIds = words.map { it.id }
    val sessionIds = remember(wordIds) {
        val due = words.filter { it.nextReviewAt <= System.currentTimeMillis() }
        (if (due.isNotEmpty()) due else words).sortedBy { it.nextReviewAt }.map { it.id }
    }
    val startedWithDueCards = remember(wordIds) { words.any { it.nextReviewAt <= System.currentTimeMillis() } }
    var index by remember(sessionIds) { mutableIntStateOf(0) }
    var revealed by remember(sessionIds) { mutableStateOf(false) }
    val activeWord = sessionIds.getOrNull(index)?.let { id -> words.firstOrNull { it.id == id } }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("A little recall goes a long way", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(if (startedWithDueCards) "These words are ready for review." else "Nothing is overdue. Use this mini-session to keep your memory active.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        if (activeWord == null) {
            ElevatedCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(46.dp))
                    Text("Session complete!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text("You reviewed ${sessionIds.size} ${if (sessionIds.size == 1) "word" else "words"}. Keep showing up and your vocabulary will grow.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = { index = 0; revealed = false }) { Icon(Icons.Default.Refresh, null); Spacer(Modifier.width(8.dp)); Text("Practise again") }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(if (startedWithDueCards) "REVIEW SESSION" else "PRACTICE SESSION", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                Text("${index + 1} / ${sessionIds.size}", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            ElevatedCard(
                modifier = Modifier.fillMaxWidth().heightIn(min = 310.dp),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    Modifier.fillMaxWidth().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("ENGLISH WORD", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(activeWord.english, modifier = Modifier.weight(1f), style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { onSpeakWord(activeWord.english) }) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear pronunciation") }
                    }
                    if (activeWord.partOfSpeech.isNotBlank()) SmallPill(activeWord.partOfSpeech)
                    if (revealed) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                        Text(activeWord.bangla, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.primary)
                        if (activeWord.englishDefinition.isNotBlank()) Text(activeWord.englishDefinition, style = MaterialTheme.typography.bodyMedium)
                        if (activeWord.example.isNotBlank()) Text(activeWord.example, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (activeWord.synonyms.isNotBlank()) Text("Synonyms: ${activeWord.synonyms}", style = MaterialTheme.typography.bodySmall)
                        Text("Memory level: ${activeWord.mastery}/5", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    } else {
                        Text("Try to recall the Bangla meaning before revealing it.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                        OutlinedButton(onClick = { revealed = true }) { Text("Reveal meaning") }
                    }
                }
            }
            if (revealed) {
                Text("How well did you remember?", fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { onReview(activeWord, false); index++; revealed = false },
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) { Text("Need practice") }
                    Button(
                        onClick = { onReview(activeWord, true); index++; revealed = false },
                        modifier = Modifier.weight(1f)
                    ) { Icon(Icons.Default.CheckCircle, null); Spacer(Modifier.width(6.dp)); Text("I knew it") }
                }
            }
            Text("Review rhythm: 1 → 3 → 7 → 14 → 30 days as your confidence grows.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun WritingScreen(words: List<Word>, entries: List<WritingEntry>, onSpeakWord: (String) -> Unit, onSave: (WritingEntry) -> Unit) {
    val sortedWords = remember(words) { words.sortedBy { it.english.lowercase() } }
    val modes = listOf("Sentence", "Paragraph", "IELTS Task 1", "IELTS Task 2")
    val connectors = listOf("However", "Moreover", "For example", "Consequently", "In contrast", "Therefore")
    val task1Prompts = listOf(
        "The table gives the percentages of commuters in a city who used four transport modes in 2010 and 2020: Car 50% → 40%; Bus 30% → 35%; Cycling 10% → 15%; Walking 10% → 10%. Summarise the information by selecting and reporting the main features, and make comparisons where relevant.",
        "The table compares the share of a household's monthly spending in 2000 and 2020: Housing 25% → 32%; Food 30% → 22%; Transport 10% → 16%; Leisure 15% → 14%; Other 20% → 16%. Summarise the main features and compare the figures.",
        "A library recorded the following visitor numbers: Monday 120, Tuesday 150, Wednesday 180, Thursday 160, Friday 220, Saturday 300 and Sunday 270. Summarise the main trends and make relevant comparisons."
    )
    val task2Prompts = listOf(
        "Some people believe that university education should be free for everyone. To what extent do you agree or disagree? Give reasons for your answer and include relevant examples.",
        "Many employees now have the option to work from home. Do the advantages of this development outweigh the disadvantages? Explain your position with examples.",
        "Some people think governments should spend more money on public transport rather than building new roads. Discuss both views and give your own opinion.",
        "Technology makes it easier for people to communicate, but some believe it is reducing the quality of personal relationships. To what extent do you agree or disagree?"
    )

    var targetIndex by remember(sortedWords) { mutableIntStateOf(0) }
    var writingMode by remember { mutableStateOf("Sentence") }
    var draft by remember(targetIndex, writingMode) { mutableStateOf("") }
    var promptIndex by remember { mutableIntStateOf(0) }
    val target = sortedWords.getOrNull(if (sortedWords.isEmpty()) 0 else targetIndex % sortedWords.size)
    val trimmed = draft.trim()
    val tokens = Regex("[A-Za-z']+").findAll(trimmed).map { it.value }.toList()
    val wordCount = tokens.size
    val uniqueCount = tokens.map { it.lowercase() }.distinct().size
    val sentenceCount = trimmed.split(Regex("[.!?]+(?=\\s|$)")).count { it.isNotBlank() }
    val usesTarget = target != null && Regex("\\b${Regex.escape(target.english)}\\b", RegexOption.IGNORE_CASE).containsMatchIn(trimmed)
    val startsWithCapital = trimmed.firstOrNull { !it.isWhitespace() }?.isUpperCase() == true
    val hasEnding = trimmed.endsWith(".") || trimmed.endsWith("!") || trimmed.endsWith("?")
    val usedConnectors = connectors.filter { connector -> trimmed.contains(connector, ignoreCase = true) }
    val grammarTips = remember(trimmed) { GrammarFeedback.analyse(trimmed) }
    val isTask1 = writingMode == "IELTS Task 1"
    val isTask2 = writingMode == "IELTS Task 2"
    val isIelts = isTask1 || isTask2
    val taskPrompt = when {
        isTask1 -> task1Prompts[promptIndex % task1Prompts.size]
        isTask2 -> task2Prompts[promptIndex % task2Prompts.size]
        else -> ""
    }
    val overviewPresent = listOf("overall", "in general", "it is clear that", "to summarise").any { trimmed.contains(it, true) }
    val conclusionPresent = listOf("in conclusion", "to conclude", "in summary", "overall").any { trimmed.contains(it, true) }
    val positionPresent = listOf("I believe", "I agree", "I disagree", "in my view", "from my perspective", "this essay argues").any { trimmed.contains(it, true) }
    val paragraphCount = trimmed.split(Regex("\\n\\s*\\n")).count { it.isNotBlank() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text("Turn vocabulary into expression", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Practise, review language suggestions, and prepare structured IELTS responses. Feedback is offline and rule-based, not an official score.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            modes.forEach { mode ->
                FilterChip(selected = writingMode == mode, onClick = { writingMode = mode }, label = { Text(mode) })
            }
        }

        if (!isIelts && target != null) {
            ElevatedCard(shape = RoundedCornerShape(22.dp), colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("YOUR TARGET WORD", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(target.english, modifier = Modifier.weight(1f), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        IconButton(onClick = { onSpeakWord(target.english) }) { Icon(Icons.Default.VolumeUp, contentDescription = "Hear pronunciation", tint = MaterialTheme.colorScheme.primary) }
                    }
                    Text(target.bangla, fontSize = 22.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (target.englishDefinition.isNotBlank()) Text(target.englishDefinition, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (target.synonyms.isNotBlank()) Text("Alternatives: ${target.synonyms}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    if (target.example.isNotBlank()) Text("Example: ${target.example}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    TextButton(onClick = { if (sortedWords.isNotEmpty()) targetIndex = (targetIndex + 1) % sortedWords.size }) {
                        Icon(Icons.Default.Refresh, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(5.dp)); Text("Choose another word")
                    }
                }
            }
        } else if (!isIelts) {
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("PERSONAL VOCABULARY", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text("Add words to your dictionary to receive a personal target word. You can still practise writing below.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        if (isIelts) {
            ElevatedCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(if (isTask1) "IELTS ACADEMIC WRITING TASK 1" else "IELTS WRITING TASK 2", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(taskPrompt, style = MaterialTheme.typography.bodyLarge)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        SmallPill(if (isTask1) "Target: 150+ words" else "Target: 250+ words")
                        TextButton(onClick = { promptIndex = (promptIndex + 1) % (if (isTask1) task1Prompts.size else task2Prompts.size) }) { Text("Another task") }
                    }
                }
            }
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text("A useful structure", fontWeight = FontWeight.Bold)
                    if (isTask1) {
                        Text("1. Introduction: paraphrase what the table or chart shows.\n2. Overview: identify the most important overall trends.\n3. Details: compare the main figures accurately.\nAvoid giving opinions or inventing reasons for the data.", style = MaterialTheme.typography.bodySmall)
                    } else {
                        Text("1. Introduction: paraphrase the question and state your position.\n2. Body paragraphs: develop separate main ideas with explanations and examples.\n3. Conclusion: summarise your answer without adding a new argument.", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else if (writingMode == "Paragraph") {
            ElevatedCard(shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("WRITING PROMPT", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(task2Prompts[promptIndex % task2Prompts.size], fontWeight = FontWeight.Medium)
                    TextButton(onClick = { promptIndex = (promptIndex + 1) % task2Prompts.size }) { Text("Another prompt") }
                }
            }
        }

        OutlinedTextField(
            value = draft,
            onValueChange = { draft = it },
            modifier = Modifier.fillMaxWidth(),
            minLines = when { isTask2 -> 12; isTask1 -> 9; writingMode == "Sentence" -> 4; else -> 8 },
            placeholder = {
                Text(when {
                    isTask1 -> "Write a report of at least 150 words. Include an overview and compare key figures..."
                    isTask2 -> "Write an essay of at least 250 words. Develop your position with reasons and examples..."
                    writingMode == "Sentence" -> "Write a sentence using “${target?.english ?: "a new word"}”..."
                    else -> "Write a paragraph. Develop your idea with examples..."
                })
            },
            label = { Text(if (isIelts) "Your response" else if (writingMode == "Sentence") "Your sentence" else "Your paragraph") },
            shape = RoundedCornerShape(18.dp)
        )

        if (!isIelts) {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("Useful connectors", fontWeight = FontWeight.SemiBold)
                Text("Tap to insert a linking expression at the end of your draft.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    connectors.forEach { connector ->
                        AssistChip(onClick = { draft = draft.trimEnd() + (if (draft.isBlank()) "" else " ") + connector + " " }, label = { Text(connector) })
                    }
                }
            }
        }

        ElevatedCard(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text(if (isIelts) "Task requirements check" else "Writing self-check", fontWeight = FontWeight.Bold)
                    SmallPill("$wordCount words")
                }
                if (isTask1) {
                    CheckLine("At least 150 words", wordCount >= 150)
                    CheckLine("An overview is included", overviewPresent)
                    CheckLine("Uses figures or numerical comparisons", Regex("\\d").containsMatchIn(trimmed))
                    CheckLine("Uses at least 2 paragraphs", paragraphCount >= 2)
                } else if (isTask2) {
                    CheckLine("At least 250 words", wordCount >= 250)
                    CheckLine("A clear position is stated", positionPresent)
                    CheckLine("A conclusion is signposted", conclusionPresent)
                    CheckLine("Uses at least 4 paragraphs", paragraphCount >= 4)
                } else {
                    if (target != null) CheckLine("Uses the target word “${target.english}”", usesTarget)
                    CheckLine("Starts with a capital letter", startsWithCapital)
                    CheckLine(if (writingMode == "Sentence") "Uses ending punctuation" else "Develops at least 3 sentences", if (writingMode == "Sentence") hasEnding else sentenceCount >= 3)
                    CheckLine(if (writingMode == "Sentence") "Uses at least 8 words" else "Uses at least 60 words", wordCount >= if (writingMode == "Sentence") 8 else 60)
                }
                HorizontalDivider()
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallPill("$uniqueCount unique words")
                    SmallPill("$sentenceCount sentences")
                    if (isIelts) SmallPill("$paragraphCount paragraphs")
                }
                if (usedConnectors.isNotEmpty()) Text("Connectors used: ${usedConnectors.joinToString()}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                if (isIelts) {
                    Text("These are practical completion checks, not an IELTS band prediction. A real assessment also considers task response, coherence, lexical resource and grammatical range and accuracy.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    Text("Tip: clarity and accuracy matter more than using as many different words as possible.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        ElevatedCard(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Text("Quick language feedback", fontWeight = FontWeight.Bold)
                    SmallPill("Offline check")
                }
                if (trimmed.isBlank()) {
                    Text("Your suggestions will appear here as you write.", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
                } else if (grammarTips.isEmpty()) {
                    Text("No issues from the built-in checks were detected. This does not guarantee the writing is error-free.", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                } else {
                    grammarTips.forEach { tip ->
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                SmallPill(tip.category)
                                Text(tip.title, fontWeight = FontWeight.SemiBold)
                            }
                            Text(tip.explanation, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(tip.suggestion, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
                Text("This is a small rule-based helper for common learner errors, not a full grammar engine or a substitute for a teacher's feedback.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        Button(onClick = {
            onSave(WritingEntry(targetWord = target?.english.orEmpty(), sentence = trimmed, kind = writingMode))
            draft = ""
        }, enabled = trimmed.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.CheckCircle, null)
            Spacer(Modifier.width(8.dp))
            Text("Save ${writingMode.lowercase()}")
        }

        if (entries.isNotEmpty()) {
            Text("Your writing notebook", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            entries.take(12).forEach { entry ->
                Card(shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            SmallPill(entry.kind)
                            Text(formatDate(entry.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(entry.sentence, style = MaterialTheme.typography.bodyLarge)
                        if (entry.targetWord.isNotBlank()) Text("Target word: ${entry.targetWord}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }
}

@Composable
private fun CheckLine(label: String, passed: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
        Icon(
            if (passed) Icons.Default.CheckCircle else Icons.Default.TipsAndUpdates,
            contentDescription = null,
            tint = if (passed) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(18.dp)
        )
        Text(label, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun WordEditorDialog(initial: Word?, onDismiss: () -> Unit, onSave: (Word) -> Unit) {
    var english by remember(initial?.id) { mutableStateOf(initial?.english.orEmpty()) }
    var bangla by remember(initial?.id) { mutableStateOf(initial?.bangla.orEmpty()) }
    var englishDefinition by remember(initial?.id) { mutableStateOf(initial?.englishDefinition.orEmpty()) }
    var pronunciation by remember(initial?.id) { mutableStateOf(initial?.pronunciation.orEmpty()) }
    var partOfSpeech by remember(initial?.id) { mutableStateOf(initial?.partOfSpeech.orEmpty()) }
    var example by remember(initial?.id) { mutableStateOf(initial?.example.orEmpty()) }
    var synonyms by remember(initial?.id) { mutableStateOf(initial?.synonyms.orEmpty()) }
    var category by remember(initial?.id) { mutableStateOf(initial?.category ?: "General") }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Add a new word" else "Edit word", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                Modifier.fillMaxWidth().heightIn(max = 560.dp).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(value = english, onValueChange = { english = it }, label = { Text("English word *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = bangla, onValueChange = { bangla = it }, label = { Text("Bangla meaning (বাংলা অর্থ) *") }, placeholder = { Text("যেমন: আনন্দ, সাহস, প্রজ্ঞা") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = englishDefinition, onValueChange = { englishDefinition = it }, label = { Text("English definition") }, placeholder = { Text("Explain the word in simple English") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = pronunciation, onValueChange = { pronunciation = it }, label = { Text("Pronunciation (optional)") }, placeholder = { Text("e.g. uh-BUN-dunt") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = partOfSpeech, onValueChange = { partOfSpeech = it }, label = { Text("Part of speech") }, placeholder = { Text("noun, verb, adjective...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = example, onValueChange = { example = it }, label = { Text("Example sentence") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                OutlinedTextField(value = synonyms, onValueChange = { synonyms = it }, label = { Text("Synonyms") }, placeholder = { Text("Separate with commas") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Category / topic") }, placeholder = { Text("Academic, daily life, IELTS...") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Personal note") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                Text("Bangla text is saved directly on your phone. You can type or paste Unicode Bangla from your keyboard.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val word = if (initial == null) {
                        Word(
                            english = english.trim(), bangla = bangla.trim(), englishDefinition = englishDefinition.trim(), pronunciation = pronunciation.trim(),
                            partOfSpeech = partOfSpeech.trim(), example = example.trim(), synonyms = synonyms.trim(),
                            category = category.trim().ifBlank { "General" }, notes = notes.trim()
                        )
                    } else {
                        initial.copy(
                            english = english.trim(), bangla = bangla.trim(), englishDefinition = englishDefinition.trim(), pronunciation = pronunciation.trim(),
                            partOfSpeech = partOfSpeech.trim(), example = example.trim(), synonyms = synonyms.trim(),
                            category = category.trim().ifBlank { "General" }, notes = notes.trim()
                        )
                    }
                    onSave(word)
                },
                enabled = english.isNotBlank() && bangla.isNotBlank()
            ) { Text("Save word") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

@Composable
private fun EmptyState(title: String, message: String, actionLabel: String? = null, onAction: (() -> Unit)? = null) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.size(76.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.MenuBook, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp)) }
        }
        Spacer(Modifier.height(18.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            Button(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
private fun SmallPill(label: String) {
    Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(50)) {
        Text(label, modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

private fun formatDate(timestamp: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
