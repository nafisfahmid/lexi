package com.lexibangla.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Forest = Color(0xFF28665B)
private val ForestDark = Color(0xFF174A42)
private val Mint = Color(0xFFDCEFE8)
private val Cream = Color(0xFFF7F8F5)
private val Ink = Color(0xFF1D2926)
private val Muted = Color(0xFF64716C)
private val Apricot = Color(0xFFF2B98B)

private val AppColors = lightColorScheme(
    primary = Forest,
    onPrimary = Color.White,
    primaryContainer = Mint,
    onPrimaryContainer = ForestDark,
    secondary = Color(0xFF8A654D),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF7E8DB),
    onSecondaryContainer = Color(0xFF4C3322),
    tertiary = Color(0xFF536C99),
    background = Cream,
    onBackground = Ink,
    surface = Color.White,
    onSurface = Ink,
    surfaceVariant = Color(0xFFEDF1ED),
    onSurfaceVariant = Muted,
    outline = Color(0xFFD4DDD7),
    error = Color(0xFFB3261E)
)

@Composable
fun LexiBanglaTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = AppColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
