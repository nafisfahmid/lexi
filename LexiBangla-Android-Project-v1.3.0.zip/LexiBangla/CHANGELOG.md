# Changelog

## 1.3.0 — IELTS writing and offline language feedback

- Added IELTS Academic Writing Task 1 practice with three prompts, data summaries, structure guidance, and checks for the 150-word target, overview, numerical comparisons, and paragraphing.
- Added IELTS Writing Task 2 practice with four prompts, essay structure guidance, and checks for the 250-word target, a stated position, a signposted conclusion, and paragraphing.
- Added offline grammar and proofreading hints for selected common learner errors, subject–verb agreement patterns, modal verb form, uncountable nouns, repeated words, spacing, capitalisation, punctuation and sentence length.
- Added clear notices that grammar hints are limited and that completion checks are not official IELTS band scores.
- Kept the existing vocabulary, phrase library, review history, local storage, and backup structure. Earlier backups remain importable.

## 1.2.0 — Vocabulary depth and learning insights

- Added an English-to-English definition field to word creation/editing, word cards, daily word, flashcards, and search.
- Added simple-English definitions to all 24 IELTS / Academic starter words.
- Added an offline library of 31 collocations and idioms with Bangla meanings, definitions, examples, categories, pronunciation playback, and spaced review.
- Added custom collocation and idiom creation.
- Added phrase review counters and forgotten-item tracking.
- Added vocabulary mastery analytics, a weak-word list based on actual review history, phrase review metrics, and writing trend indicators.
- Added backup schema version 3 while retaining compatibility with older word/writing backups.

## 1.1.0 — Study tools

- Added academic vocabulary, daily goals, quiz, writing prompts, paragraph practice, and Android text-to-speech.
- Added review scheduling and backup support.

## 1.0.0 — Personal dictionary

- Added offline English–Bangla vocabulary storage, search, favourites, flashcards, writing notebook, and JSON backup/restore.
