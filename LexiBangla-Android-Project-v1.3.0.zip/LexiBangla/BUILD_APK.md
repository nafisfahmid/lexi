# Build an installable LexiBangla 1.3.0 APK

This source project is configured for a debug APK. A debug APK is suitable for installing on your own Android phone; it is not a Play Store release build.

## Requirements

- Android Studio with Android SDK Platform 36 and Build Tools installed
- JDK 17
- Gradle 8.13
- Internet access on the build machine for the first Gradle sync, Android Gradle Plugin and Maven dependencies

## Build on Windows

1. Extract the ZIP and open the `LexiBangla` folder in Android Studio.
2. If the Gradle wrapper reports `GradleWrapperMain` missing, install Gradle 8.13 and run `gradle wrapper --gradle-version 8.13` from the project root.
3. Confirm Android SDK Platform 36 is installed in Android Studio's SDK Manager.
4. In Android Studio, select **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run `gradlew.bat assembleDebug` in a terminal.

## Build on macOS / Linux

1. Extract the ZIP and open the `LexiBangla` folder in Android Studio.
2. If the Gradle wrapper JAR is missing, install Gradle 8.13 and run `gradle wrapper --gradle-version 8.13` from the project root.
3. Confirm Android SDK Platform 36 is installed and `ANDROID_HOME` points to your SDK, if required by your environment.
4. Run `./gradlew assembleDebug`.

## APK location

After a successful build, the installable APK is:

`app/build/outputs/apk/debug/app-debug.apk`

Copy that APK to your phone and open it to install. You may need to allow installation from the file manager or browser you used to download it.

## Current verification status

The offline grammar-feedback component compiles independently and six focused behaviour checks pass. The full Android build has not been run in the authoring environment: the Android SDK and Gradle wrapper JAR are absent, and external dependency downloads are blocked. Do not treat this source ZIP as an APK.
