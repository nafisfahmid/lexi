#!/usr/bin/env bash
set -euo pipefail

if ! command -v gradle >/dev/null 2>&1 && [[ ! -f gradle/wrapper/gradle-wrapper.jar ]]; then
  echo "Gradle 8.13 is required to generate the missing Gradle wrapper JAR." >&2
  echo "Install Gradle 8.13, then run: gradle wrapper --gradle-version 8.13" >&2
  exit 2
fi

if [[ ! -f gradle/wrapper/gradle-wrapper.jar ]]; then
  gradle wrapper --gradle-version 8.13
fi

if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo "Warning: ANDROID_HOME / ANDROID_SDK_ROOT is not set. Android Gradle Plugin may need the SDK path configured in local.properties." >&2
fi

./gradlew assembleDebug
APK="app/build/outputs/apk/debug/app-debug.apk"
if [[ -f "$APK" ]]; then
  echo "APK created: $APK"
else
  echo "Build completed but expected APK was not found at $APK" >&2
  exit 3
fi
