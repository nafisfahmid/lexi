# Changelog

## 1.4.0 — Complete IELTS writing toolkit and connector guide

- Added an offline guide of 128 curated linking expressions and conjunctions across 16 functional categories: addition, contrast, concession, cause, result, examples, sequence, comparison, clarification, emphasis, conclusion, condition, purpose, time, Task 1 data language, and opinion.
- Every connector entry includes a Bangla meaning, plain-English function, grammatical pattern, where/when to place it, an example, and a common mistake or usage caution.
- Added a placement guide explaining what tends to appear in introductions, first body points, support/examples, contrast, cause/result, conclusions, Academic Task 1 overviews, and General Training letters.
- Added search by expression, Bangla meaning or function, plus category filters and copy-to-clipboard.
- Added complete IELTS task-type guides for Academic Task 1 (line/bar/pie/table/mixed charts, process/flow charts, maps/plans, object/life-cycle diagrams), General Training Task 1 (formal, semi-formal and informal letters), and common Task 2 prompt families (opinion, discussion, advantages/disadvantages, problems/solutions, causes/effects, two-part questions, positive/negative development, and affected-group questions).
- Added IELTS General Training Task 1 letter writing in the Writing Studio, with sample prompts and basic greeting, purpose, word-count and closing checks. Bullet-point coverage and register remain a manual review.
- Expanded Academic Task 1 and Task 2 writing prompts to cover more task patterns.
- Added a planning-notes field to IELTS writing drafts; plans are saved with the response and included in JSON backups. Older backups load with an empty plan.
- Added a connector-use review that detects expressions and flags repeated linkers for the writer to review. It is advisory, not an automatic deduction or band score.
- Added a four-criteria high-band practice checklist, a four-week study plan, and official IELTS resource links.
- Updated release metadata to version 1.4.0 (versionCode 5). Existing local words, phrases and writing records remain compatible.

## 1.3.0 — IELTS writing and offline language feedback

- Added IELTS Academic Writing Task 1 practice with data summaries, structure guidance, and checks for the 150-word target, overview, numerical comparisons, and paragraphing.
- Added IELTS Writing Task 2 practice with essay structure guidance, and checks for the 250-word target, a stated position, a signposted conclusion, and paragraphing.
- Added offline grammar and proofreading hints for selected common learner errors, subject–verb agreement patterns, modal verb form, uncountable nouns, repeated words, spacing, capitalisation, punctuation and sentence length.
- Added clear notices that grammar hints are limited and that completion checks are not official IELTS band scores.
- Kept the existing vocabulary, phrase library, review history, local storage, and backup structure. Earlier backups remain importable.

## 1.2.0 — Vocabulary depth and learning insights

- Added an English-to-English definition field to word creation/editing, word cards, daily word, flashcards, and search.
- Added simple-English definitions to all 24 IELTS / Academic starter words.
- Added an offline library of 31 collocations and idioms with Bangla meanings, definitions, examples, categories, pronunciation playback, and spaced review.
- Added custom collocation and idiom creation.
- Added phrase review counters and forgotten-item tracking.
- Added vocabulary mastery analytics, a weak-word list based on actual review history, phrase review metrics, and writing trend indicators.
- Added backup schema version 3 while retaining compatibility with older word/writing backups.

## 1.1.0 — Study tools

- Added academic vocabulary, daily goals, quiz, writing prompts, paragraph practice, and Android text-to-speech.
- Added review scheduling and backup support.

## 1.0.0 — Personal dictionary

- Added offline English–Bangla vocabulary storage, search, favourites, flashcards, writing notebook, and JSON backup/restore.
