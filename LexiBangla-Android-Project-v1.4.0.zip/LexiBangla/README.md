# LexiBangla — Android vocabulary and IELTS writing companion

LexiBangla is an offline-first Android learning app for collecting English words with Bangla meanings, practising vocabulary and collocations, and developing writing skills for IELTS Academic and General Training.

## Version 1.4.0 features

### Personal vocabulary
- English–Bangla dictionary with Unicode Bangla storage.
- English definitions, pronunciation, part of speech, examples, synonyms, topics, notes and favourites.
- Search, word of the day, pronunciation playback, spaced repetition, flashcards and quizzes.
- Optional academic vocabulary pack, daily word goals and learning insights.

### Collocations and idioms
- 31 starter collocations/idioms with definitions, Bangla meanings, examples, categories and spaced review.
- Add and practise your own expressions.

### Connector and linking-expression guide
- **128 curated expressions** covering addition, contrast, concession, cause, result, examples, sequence, comparison, clarification, emphasis, conclusions, conditions, purpose, time, Task 1 data comparisons and opinion language.
- Each entry provides a Bangla meaning, plain-English function, grammar pattern, where/when to use it, an example and a warning about a common misuse.
- Search by English expression, Bangla meaning or function; filter by category; copy a phrase into the clipboard.
- A placement guide explains how to use linkers in introductions, first body points, supporting points, examples, contrast, cause/result, conclusions, Academic Task 1 overviews and General Training letters.
- The writer checks for repeated linkers and asks you to review them. It does not automatically penalise repetition; the correct choice depends on the relationship between ideas.

> The guide is a carefully selected learning reference, not a claim to contain every possible connective in English. Natural cohesion also comes from paragraph structure, reference words, substitution, topic progression and accurate grammar—not linkers alone.

### IELTS writing support
- **Academic Task 1:** practice and task guidance for line graphs, bar charts, pie charts, tables, mixed visuals, process/flow charts, maps/plans and object/life-cycle diagrams.
- **General Training Task 1:** formal, semi-formal and informal letter guidance, sample prompts, greeting/purpose/closing checks and a reminder to address all three bullet points.
- **Task 2:** opinion/agree-disagree, discuss-both-views, advantages/disadvantages, problem/solution, cause/effect, two-part/direct questions, positive/negative development and affected-group prompts.
- Dedicated task structure guidance, rotating prompts, word counts, paragraph counts and simple completion checks.
- A planning-notes field is saved with the final writing sample and exported in backups.
- Four-criteria high-band checklist covering Task Achievement/Response, Coherence and Cohesion, Lexical Resource, and Grammatical Range and Accuracy.
- Four-week study plan, time allocation reminders, and quick proofreading checklist.
- Offline rule-based grammar suggestions for selected common errors and proofreading checks.

**Important score note:** The app does not assign an official IELTS band score, guarantee Band 8.5, or replace a qualified teacher/examiner. Its grammar rules and completion checks are limited. The official descriptors reward fully relevant task response, logical progression, accurate and flexible vocabulary, and a wide range of controlled grammar. Using more connectors or rare words by itself does not make writing high-band.

## IELTS format reference in the app

- Total Writing time: 60 minutes.
- Task 1: at least 150 words; approximately 20 minutes.
- Task 2: at least 250 words; approximately 40 minutes.
- Task 2 carries twice as much weight as Task 1 in the Writing score.
- Academic Task 1 describes visual information; General Training Task 1 is a letter.
- Both versions have an essay in Task 2.

These are aligned with official IELTS test-format guidance. Always check official IELTS resources for the latest instructions and your test type.

## Open in Android Studio

1. Install Android Studio with Android SDK Platform 36 and JDK 17.
2. Extract the ZIP and open the **LexiBangla** project directory.
3. Allow Gradle to sync and download the pinned dependencies.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Select the `app` run configuration and press **Run**.

**Gradle wrapper note:** this source archive does not contain the binary `gradle-wrapper.jar`. If Android Studio reports `GradleWrapperMain` missing, install Gradle 8.13 locally and run `gradle wrapper --gradle-version 8.13` from the project root, or configure Android Studio to use that local Gradle 8.13 installation. A first build also needs network access to fetch Gradle/Android dependencies.

To build a debug APK after the wrapper is generated:

```bash
./gradlew assembleDebug
```

On Windows:

```bat
gradlew.bat assembleDebug
```

The debug APK is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

See [BUILD_APK.md](BUILD_APK.md) for detailed steps.

## Bangla input and data

- Bangla meaning fields accept standard Unicode text. Use a Bangla keyboard (for example, Gboard Bangla) or paste text into the field.
- Words, phrases, writing and planning notes are stored locally in the app's private storage.
- Export a JSON backup before moving to another phone or reinstalling.
- JSON backups are UTF-8 and preserve Bangla Unicode characters.
- Older writing backups without a planning-notes property restore with an empty plan field.
- Existing v1.0, v1.1, v1.2 and v1.3 data formats remain supported.

## Build and verification notes

- Kotlin + Jetpack Compose + Material 3.
- Minimum Android: Android 8.0 (API 26).
- Compile/target SDK: 36.
- JDK target: 17.
- Release: 1.4.0 (versionCode 5).
- Application ID: `com.lexibangla.app`.
- The connector guide data compiles independently with Kotlin and is checked for required fields. A full Android build/device run requires Android SDK, Gradle wrapper JAR and dependency downloads on the build machine.

## Research and official references

The in-app explanations and practice structure were informed by these public IELTS resources, checked on 10 November 2026:

1. IELTS — [Academic Writing test format](https://ielts.org/take-a-test/test-types/ielts-academic-test/ielts-academic-format-writing)
2. IELTS — [General Training Writing test format](https://ielts.org/take-a-test/test-types/ielts-general-training-test/ielts-general-training-format-writing)
3. IELTS — [Writing test preparation resources and assessment criteria](https://ielts.org/take-a-test/preparation-resources/writing-test-resources)
4. IELTS — [Official Writing band descriptors (PDF)](https://ielts.org/cdn/ielts-guides/ielts-writing-band-descriptors.pdf)
5. British Council IELTS — [Coherence and cohesion in IELTS writing](https://takeielts.britishcouncil.org/prepare/ielts-academic/writing/tips-coherence-cohesion?language=en)

The connector entries are original instructional summaries with Bangla explanations and examples; they are not copied as an official IELTS word list.
