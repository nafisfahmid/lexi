package com.lexibangla.app.data

import java.util.UUID

data class Word(
    val id: String = UUID.randomUUID().toString(),
    val english: String,
    val bangla: String,
    val englishDefinition: String = "",
    val pronunciation: String = "",
    val partOfSpeech: String = "",
    val example: String = "",
    val synonyms: String = "",
    val category: String = "General",
    val notes: String = "",
    val favorite: Boolean = false,
    val mastery: Int = 0,
    val reviewCount: Int = 0,
    val forgottenCount: Int = 0,
    val nextReviewAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class Phrase(
    val id: String = UUID.randomUUID().toString(),
    val phrase: String,
    val kind: String = "Collocation",
    val englishDefinition: String,
    val bangla: String,
    val example: String = "",
    val category: String = "General",
    val mastery: Int = 0,
    val reviewCount: Int = 0,
    val forgottenCount: Int = 0,
    val nextReviewAt: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)

data class WritingEntry(
    val id: String = UUID.randomUUID().toString(),
    val targetWord: String,
    val sentence: String,
    val kind: String = "Sentence",
    val plan: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
