package com.lexibangla.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.Button
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lexibangla.app.data.ConnectorGuide
import com.lexibangla.app.data.ConnectorGuideItem

private val ieltsToolkitSections = listOf("Connectors", "Task types", "Band 8.5 path", "Study plan")

@Composable
fun IeltsToolkitScreen() {
    var section by remember { mutableStateOf("Connectors") }
    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp, vertical = 8.dp)) {
        Text("IELTS writing toolkit", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(
            "A practical guide for Academic and General Training writing. Learn where language belongs, then practise using it accurately.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            ieltsToolkitSections.forEach { item ->
                FilterChip(selected = section == item, onClick = { section = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(8.dp))
        when (section) {
            "Connectors" -> ConnectorGuideScreen()
            "Task types" -> IeltsTaskTypesScreen()
            "Band 8.5 path" -> BandEightFiveScreen()
            else -> IeltsStudyPlanScreen()
        }
    }
}

@Composable
private fun ConnectorGuideScreen() {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("All") }
    val clipboard = LocalClipboardManager.current
    val filtered = remember(query, category) {
        ConnectorGuide.entries.filter { item ->
            (category == "All" || item.category == category) &&
                (query.isBlank() || listOf(item.phrase, item.bangla, item.meaning, item.pattern, item.example, item.category)
                    .any { it.contains(query.trim(), ignoreCase = true) })
        }
    }
    var showPlacementGuide by remember { mutableStateOf(true) }
    Column(Modifier.fillMaxSize()) {
        Card(
            onClick = { showPlacementGuide = !showPlacementGuide },
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Which connector goes where?  ▾", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
                if (showPlacementGuide) {
                    Text("Introduction: usually state the topic and your position directly; a linker is not compulsory.", style = MaterialTheme.typography.bodySmall)
                    Text("First body point: 'To begin with' or 'One reason is that…' when you need to signal the first reason.", style = MaterialTheme.typography.bodySmall)
                    Text("Add support: 'Furthermore' / 'In addition' for a genuinely new supporting point; 'For example' before an illustration.", style = MaterialTheme.typography.bodySmall)
                    Text("Contrast: 'However' / 'By contrast' between sentences; 'although' / 'whereas' to connect clauses inside one sentence.", style = MaterialTheme.typography.bodySmall)
                    Text("Cause: 'because / since + clause'; 'because of / due to + noun phrase'. Result: 'therefore / consequently / as a result'.", style = MaterialTheme.typography.bodySmall)
                    Text("Final paragraph: 'In conclusion' / 'On balance' for a final judgement. Academic Task 1 overview: 'Overall'. General Task 1: choose transitions that match the letter's purpose and tone.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Search connectors or Bangla meanings") },
            placeholder = { Text("e.g. however, কারণ, contrast, at the beginning") }
        )
        Spacer(Modifier.height(7.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ConnectorGuide.categories.forEach { item ->
                FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item) })
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            "${filtered.size} expressions · ${ConnectorGuide.entries.size} curated entries. Tap a card for its meaning, grammar pattern, position, example and caution.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(5.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
            items(filtered, key = { it.phrase }) { item ->
                ConnectorCard(item) { clipboard.setText(AnnotatedString(item.phrase)) }
            }
        }
    }
}

@Composable
private fun ConnectorCard(item: ConnectorGuideItem, onCopy: () -> Unit) {
    var expanded by remember(item.phrase) { mutableStateOf(false) }
    Card(
        onClick = { expanded = !expanded },
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(15.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(item.phrase, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(item.bangla, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                }
                Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(50)) {
                    Text(item.category, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), style = MaterialTheme.typography.labelSmall)
                }
            }
            Text(item.meaning, style = MaterialTheme.typography.bodySmall)
            if (expanded) {
                Spacer(Modifier.height(3.dp))
                GuideDetail("Grammar pattern", item.pattern)
                GuideDetail("Where to use it", item.placement)
                GuideDetail("Example", item.example)
                if (item.caution.isNotBlank()) GuideDetail("Common mistake / advice", item.caution)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onCopy) { Text("Copy expression") }
                }
            } else {
                Text("Tap to see pattern, placement and example", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun GuideDetail(label: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        Text(body, style = MaterialTheme.typography.bodySmall)
    }
}

private data class TaskGuide(
    val title: String,
    val format: String,
    val questionForms: String,
    val structure: String,
    val language: String
)

@Composable
private fun IeltsTaskTypesScreen() {
    val academic = listOf(
        TaskGuide("Line graph", "Describe change over time", "One or more lines showing trends across dates.", "Introduction → overview of main trends → 2 detail paragraphs grouped by major patterns.", "rise, fall, fluctuate, remain stable; from…to; by; respectively; whereas"),
        TaskGuide("Bar chart", "Compare categories or time periods", "Vertical or horizontal bars; may show one or more years.", "Introduction → overview of highest/lowest or largest differences → grouped comparisons with accurate figures.", "higher/lower than, compared with, approximately, twice as many, stood at"),
        TaskGuide("Pie chart", "Compare proportions or shares", "One or more circles divided into percentages or proportions.", "Introduction → overview of dominant and smallest shares / major changes → grouped percentage comparisons.", "accounted for, represented, proportion, share, percentage points"),
        TaskGuide("Table", "Select and compare important data", "Rows and columns with categories, values or dates.", "Introduction → overview of key highs/lows or patterns → detail paragraphs grouping related rows or columns.", "respectively, in comparison, the figure for, recorded, the highest/lowest"),
        TaskGuide("Mixed charts", "Connect two different visual formats", "For example, a bar chart and a line graph about one topic.", "Introduction → overview covering both visuals → details grouped by the relationship between them.", "while, whereas, in parallel, by comparison; describe each visual and the link between them"),
        TaskGuide("Process / flow chart", "Explain stages and direction", "A man-made process or natural cycle with arrows and stages.", "Introduction → overview of start/end and number of stages → chronological stages in logical groups.", "initially, next, subsequently, after this, finally; is heated, is transferred, is produced"),
        TaskGuide("Maps / plans", "Describe spatial changes", "Two or more maps showing a place at different times, or proposed changes.", "Introduction → overview of the biggest changes → describe key areas using clear spatial references.", "to the north of, adjacent to, replaced by, converted into, expanded, demolished"),
        TaskGuide("Object / life-cycle diagram", "Explain parts or stages", "A labelled object, system, biological cycle or sequence.", "Introduction → overview of main components/stages → explain the sequence or parts in a clear order.", "consists of, is composed of, passes through, in the next stage, leads to")
    )
    val taskTwo = listOf(
        TaskGuide("Opinion / agree or disagree", "Take a clear position", "To what extent do you agree or disagree? / Do you agree or disagree?", "Introduction with a direct position → 2 developed reasons → conclusion that reflects the same position.", "I would argue that; this is because; for this reason; nevertheless"),
        TaskGuide("Discuss both views + opinion", "Explain both sides and give your view", "Discuss both views and give your own opinion.", "Introduction with stance → view A → view B and your evaluation → conclusion with your judgement.", "Supporters argue; by contrast; although; on balance; in my view"),
        TaskGuide("Advantages and disadvantages", "Evaluate benefits and drawbacks", "What are the advantages and disadvantages? / Do the advantages outweigh the disadvantages?", "Introduction → benefits → drawbacks → explicit comparison and judgement if 'outweigh' is asked.", "One benefit; a significant drawback; whereas; nevertheless; on balance"),
        TaskGuide("Problems and solutions", "Identify problems and practical remedies", "What problems does this cause, and what solutions can you suggest?", "Introduction → explain major problems and causes → match each problem with a realistic solution → conclusion.", "This can lead to; as a consequence; one measure would be; to address this"),
        TaskGuide("Causes and effects", "Explain why something happens and what follows", "Why is this happening? What effects does it have?", "Introduction → develop the main causes → explain direct and wider effects → conclusion.", "This is largely because; owing to; consequently; this in turn"),
        TaskGuide("Two-part / direct questions", "Answer every question in the prompt", "A topic followed by two separate questions, such as why and whether.", "Introduction that previews both answers → one focused paragraph per question → conclusion answering both.", "Regarding the first question; as for; a further reason; therefore"),
        TaskGuide("Positive or negative development", "Make an overall evaluation", "Is this a positive or negative development?", "Introduction with a clear overall judgement → develop positive/negative effects → acknowledge the other side if relevant → conclusion.", "Overall; a beneficial consequence; a potential drawback; despite this"),
        TaskGuide("Benefits to whom / who is affected", "Identify affected groups", "Who benefits? Is this a positive change for individuals or society?", "Define the groups → explain distinct effects on each → compare significance and give a direct answer.", "For individuals; at a societal level; whereas; in particular")
    )
    val generalLetters = listOf(
        TaskGuide("Formal letter", "Write to someone you do not know or an organisation", "Complaint, request for information, application, report of a problem or suggestion.", "Dear Sir or Madam / Dear [title] → purpose → details covering all 3 bullet points → requested action → Yours faithfully / Yours sincerely.", "I am writing to enquire; I would be grateful if; I would appreciate; I look forward to"),
        TaskGuide("Semi-formal letter", "Write to someone you know in a professional or official context", "For example, a landlord, teacher, manager or neighbour you know.", "Dear [Name/Title] → polite purpose → details and explanation → specific request or next step → appropriate sign-off.", "I am writing regarding; I was wondering whether; would it be possible; Kind regards"),
        TaskGuide("Informal letter", "Write to a friend or relative", "Advice, invitation, thanks, apology, news or a personal explanation.", "Hi/Dear [first name] → friendly opening → respond to all bullet points naturally → warm closing → Best wishes / Take care.", "Thanks for your letter; it was great to hear; why don't we; hope to see you soon")
    )
    LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item { IntroCard("IELTS Academic Task 1", "At least 150 words · about 20 minutes", "Report only what the visuals show. Select key features, give a clear overview, and support comparisons with accurate data.") }
        items(academic) { TaskGuideCard(it) }
        item { IntroCard("IELTS General Training Task 1", "At least 150 words · about 20 minutes", "Write a connected letter, not notes. Cover every bullet point and match the tone to the reader and purpose.") }
        items(generalLetters) { TaskGuideCard(it) }
        item { IntroCard("IELTS Writing Task 2", "At least 250 words · about 40 minutes", "Both Academic and General Training use an essay task. Identify every part of the prompt and develop relevant ideas with explanation and examples.") }
        items(taskTwo) { TaskGuideCard(it) }
        item {
            Text("Official format note: the Writing test lasts 60 minutes. Task 2 carries twice the weight of Task 1 in the Writing score, so plan your time accordingly.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun IntroCard(title: String, subtitle: String, body: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
private fun TaskGuideCard(task: TaskGuide) {
    var expanded by remember(task.title) { mutableStateOf(false) }
    Card(onClick = { expanded = !expanded }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(13.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(task.title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(task.format, color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
            Text(task.questionForms, style = MaterialTheme.typography.bodySmall)
            if (expanded) {
                GuideDetail("Suggested structure", task.structure)
                GuideDetail("Useful language", task.language)
            } else {
                Text("Tap for structure and useful language", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun BandEightFiveScreen() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            IntroCard(
                "Aim for consistently excellent writing",
                "Band 8.5 is a goal, not a feature-generated promise",
                "IELTS Writing is assessed by human examiners using four equally weighted criteria. Task 2 contributes twice as much as Task 1 to the overall Writing score. This checklist helps you practise the qualities described in the official high-band descriptors; it cannot predict your score."
            )
        }
        item { BandCriterion("Task achievement / response", "Answer every part of the prompt. For Academic Task 1, select and highlight key features and give a clear overview. For General Task 1, cover all bullet points and achieve the letter's purpose. For Task 2, take a clear position and extend relevant ideas with explanation and support.", "Before submitting: underline the task instructions; check that every question is answered; remove irrelevant material; make examples specific and plausible.") }
        item { BandCriterion("Coherence and cohesion", "Make the response easy to follow. Sequence ideas logically, use clear paragraphing and connect ideas smoothly. Cohesive devices should express the real relationship between ideas rather than appear mechanically.", "Before submitting: write one central idea per body paragraph; check pronoun references; highlight repeated connectors; remove any linker that adds no meaning.") }
        item { BandCriterion("Lexical resource", "Use a wide range of vocabulary precisely and naturally. Strong performance comes from accurate word choice, collocation, paraphrase and control—not from choosing the rarest possible word.", "Before submitting: check collocations, word forms, spelling and repeated words; replace vague vocabulary only when a more precise phrase is genuinely correct.") }
        item { BandCriterion("Grammatical range and accuracy", "Use varied sentence structures with control. Complex structures are useful when they clarify relationships, but accuracy and punctuation matter more than length.", "Before submitting: check subject–verb agreement, articles, tense, clause boundaries, comma splices and sentence fragments. Read each sentence aloud.") }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("High-value habits", fontWeight = FontWeight.Bold)
                    Text("• Plan before writing; do not memorise a whole essay.\n• Address the exact question, not a rehearsed topic.\n• Develop each main idea: claim → explanation → example or consequence.\n• Use cohesive devices selectively and accurately.\n• Leave time to proofread.\n• Practise under timed conditions and rewrite after feedback.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            val context = LocalContext.current
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Official assessment resources", fontWeight = FontWeight.Bold)
                    Text("Review the actual criteria and test format from IELTS and the British Council.", style = MaterialTheme.typography.bodySmall)
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://ielts.org/take-a-test/preparation-resources/writing-test-resources"))) }) { Text("IELTS writing resources ↗") }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://ielts.org/cdn/ielts-guides/ielts-writing-band-descriptors.pdf"))) }) { Text("Official writing band descriptors ↗") }
                    TextButton(onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://takeielts.britishcouncil.org/prepare/ielts-academic/writing/tips-coherence-cohesion?language=en"))) }) { Text("British Council: coherence and cohesion ↗") }
                }
            }
        }
    }
}

@Composable
private fun BandCriterion(title: String, descriptor: String, checklist: String) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(descriptor, style = MaterialTheme.typography.bodySmall)
            Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(10.dp)) {
                Text(checklist, Modifier.padding(10.dp), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun IeltsStudyPlanScreen() {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 18.dp)) {
        item {
            IntroCard(
                "A repeatable practice cycle",
                "Analyse → plan → write → review → rewrite",
                "A strong score requires consistent performance across all four criteria. This four-week plan gives structure, but adapt the pace to your current level and available study time."
            )
        }
        item { PlanWeek("Week 1 · Understand the tasks", "Learn the difference between Academic and General Training Task 1. Identify all Task 2 question types. Practise breaking prompts into instruction words, topic, scope and separate questions.", "Complete 3 untimed Task 1 plans and 3 Task 2 outlines. Do not write full essays yet.") }
        item { PlanWeek("Week 2 · Build language control", "Study connector patterns and punctuation. Practise complex sentences, comparison, cause and effect, concession, articles, verb agreement and topic vocabulary. Learn collocations in context.", "Write 5 focused paragraphs. Highlight connectors and explain what relationship each one expresses.") }
        item { PlanWeek("Week 3 · Timed task practice", "Practise Academic reports or General letters, then Task 2 essays. Use clear paragraph plans, precise data or specific supporting examples, and a short proofreading stage.", "Complete 3 Task 1 responses in about 20 minutes and 3 Task 2 essays in about 40 minutes.") }
        item { PlanWeek("Week 4 · Full practice and revision", "Complete full 60-minute writing sessions. Review recurring errors, weak question types, repetitive connectors and unsupported ideas. Rewrite weak responses after feedback.", "Complete at least 2 full Writing tests, then compare them against the four assessment criteria.") }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Suggested time allocation", fontWeight = FontWeight.Bold)
                    Text("Task 1: approximately 20 minutes · Task 2: approximately 40 minutes. Task 2 has twice the weight, so do not spend too long polishing Task 1.", style = MaterialTheme.typography.bodySmall)
                    Text("Minimum length: 150 words for Task 1 and 250 words for Task 2. Reaching the minimum is not enough by itself; relevance, development, organisation and language control matter.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            Card {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("A 5-minute final check", fontWeight = FontWeight.Bold)
                    Text("1. Did I answer all parts of the task?\n2. Is my position or overview unmistakable?\n3. Does every paragraph have a clear purpose?\n4. Are my examples relevant and explained?\n5. Are connectors, collocations and grammar accurate?\n6. Have I checked spelling, articles, verb forms and punctuation?", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun PlanWeek(title: String, focus: String, output: String) {
    Card {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(title, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text(focus, style = MaterialTheme.typography.bodySmall)
            Text(output, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        }
    }
}
