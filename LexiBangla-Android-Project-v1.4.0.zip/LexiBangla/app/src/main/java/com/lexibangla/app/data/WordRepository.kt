package com.lexibangla.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Offline-first store. JSON strings preserve Bangla Unicode text in backups and local preferences. */
class WordRepository(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("lexibangla_store", Context.MODE_PRIVATE)

    fun loadWords(): List<Word> = parseWords(prefs.getString(KEY_WORDS, "[]"))
    fun loadWritingEntries(): List<WritingEntry> = parseWritings(prefs.getString(KEY_WRITINGS, "[]"))

    fun loadPhrases(): List<Phrase> {
        if (!prefs.contains(KEY_PHRASES)) {
            savePhrases(PhrasePack.entries)
        }
        return parsePhrases(prefs.getString(KEY_PHRASES, "[]"))
    }

    fun loadDailyGoal(): Int = prefs.getInt(KEY_DAILY_GOAL, 5).coerceIn(1, 30)
    fun saveDailyGoal(goal: Int) { prefs.edit().putInt(KEY_DAILY_GOAL, goal.coerceIn(1, 30)).apply() }
    fun saveWords(words: List<Word>) { prefs.edit().putString(KEY_WORDS, wordsToJson(words).toString()).apply() }
    fun saveWritingEntries(entries: List<WritingEntry>) { prefs.edit().putString(KEY_WRITINGS, writingsToJson(entries).toString()).apply() }
    fun savePhrases(phrases: List<Phrase>) { prefs.edit().putString(KEY_PHRASES, phrasesToJson(phrases).toString()).apply() }

    fun exportBackup(): String = JSONObject()
        .put("app", "LexiBangla")
        .put("version", 3)
        .put("dailyGoal", loadDailyGoal())
        .put("words", wordsToJson(loadWords()))
        .put("writings", writingsToJson(loadWritingEntries()))
        .put("phrases", phrasesToJson(loadPhrases()))
        .toString(2)

    /** Accepts v1.0/v1.1 backups; new phrase data is optional for backward compatibility. */
    fun importBackup(json: String): Boolean {
        return try {
            val root = JSONObject(json)
            val wordsArray = root.optJSONArray("words") ?: return false
            val writingsArray = root.optJSONArray("writings") ?: JSONArray()
            val words = parseWords(wordsArray.toString())
            val writings = parseWritings(writingsArray.toString())
            val phrases = if (root.has("phrases")) {
                parsePhrases(root.optJSONArray("phrases")?.toString() ?: "[]")
            } else {
                loadPhrases()
            }
            prefs.edit()
                .putString(KEY_WORDS, wordsToJson(words).toString())
                .putString(KEY_WRITINGS, writingsToJson(writings).toString())
                .putString(KEY_PHRASES, phrasesToJson(phrases).toString())
                .putInt(KEY_DAILY_GOAL, root.optInt("dailyGoal", loadDailyGoal()).coerceIn(1, 30))
                .apply()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun wordsToJson(words: List<Word>) = JSONArray().apply {
        words.forEach { word ->
            put(JSONObject()
                .put("id", word.id)
                .put("english", word.english)
                .put("bangla", word.bangla)
                .put("englishDefinition", word.englishDefinition)
                .put("pronunciation", word.pronunciation)
                .put("partOfSpeech", word.partOfSpeech)
                .put("example", word.example)
                .put("synonyms", word.synonyms)
                .put("category", word.category)
                .put("notes", word.notes)
                .put("favorite", word.favorite)
                .put("mastery", word.mastery)
                .put("reviewCount", word.reviewCount)
                .put("forgottenCount", word.forgottenCount)
                .put("nextReviewAt", word.nextReviewAt)
                .put("createdAt", word.createdAt)
            )
        }
    }

    private fun phrasesToJson(phrases: List<Phrase>) = JSONArray().apply {
        phrases.forEach { phrase ->
            put(JSONObject()
                .put("id", phrase.id)
                .put("phrase", phrase.phrase)
                .put("kind", phrase.kind)
                .put("englishDefinition", phrase.englishDefinition)
                .put("bangla", phrase.bangla)
                .put("example", phrase.example)
                .put("category", phrase.category)
                .put("mastery", phrase.mastery)
                .put("reviewCount", phrase.reviewCount)
                .put("forgottenCount", phrase.forgottenCount)
                .put("nextReviewAt", phrase.nextReviewAt)
                .put("createdAt", phrase.createdAt)
            )
        }
    }

    private fun writingsToJson(entries: List<WritingEntry>) = JSONArray().apply {
        entries.forEach { entry ->
            put(JSONObject()
                .put("id", entry.id)
                .put("targetWord", entry.targetWord)
                .put("sentence", entry.sentence)
                .put("kind", entry.kind)
                .put("plan", entry.plan)
                .put("createdAt", entry.createdAt)
            )
        }
    }

    private fun parseWords(raw: String?): List<Word> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val english = item.optString("english").trim()
                    val bangla = item.optString("bangla").trim()
                    if (english.isBlank() || bangla.isBlank()) continue
                    add(Word(
                        id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        english = english,
                        bangla = bangla,
                        englishDefinition = item.optString("englishDefinition"),
                        pronunciation = item.optString("pronunciation"),
                        partOfSpeech = item.optString("partOfSpeech"),
                        example = item.optString("example"),
                        synonyms = item.optString("synonyms"),
                        category = item.optString("category").ifBlank { "General" },
                        notes = item.optString("notes"),
                        favorite = item.optBoolean("favorite", false),
                        mastery = item.optInt("mastery", 0).coerceIn(0, 5),
                        reviewCount = item.optInt("reviewCount", 0).coerceAtLeast(0),
                        forgottenCount = item.optInt("forgottenCount", 0).coerceAtLeast(0),
                        nextReviewAt = item.optLong("nextReviewAt", 0L),
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun parsePhrases(raw: String?): List<Phrase> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val phrase = item.optString("phrase").trim()
                    val definition = item.optString("englishDefinition").trim()
                    if (phrase.isBlank() || definition.isBlank()) continue
                    add(Phrase(
                        id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        phrase = phrase,
                        kind = item.optString("kind").ifBlank { "Collocation" },
                        englishDefinition = definition,
                        bangla = item.optString("bangla"),
                        example = item.optString("example"),
                        category = item.optString("category").ifBlank { "General" },
                        mastery = item.optInt("mastery", 0).coerceIn(0, 5),
                        reviewCount = item.optInt("reviewCount", 0).coerceAtLeast(0),
                        forgottenCount = item.optInt("forgottenCount", 0).coerceAtLeast(0),
                        nextReviewAt = item.optLong("nextReviewAt", 0L),
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private fun parseWritings(raw: String?): List<WritingEntry> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val sentence = item.optString("sentence").trim()
                    if (sentence.isBlank()) continue
                    add(WritingEntry(
                        id = item.optString("id").ifBlank { UUID.randomUUID().toString() },
                        targetWord = item.optString("targetWord"),
                        sentence = sentence,
                        kind = item.optString("kind").ifBlank { "Sentence" },
                        plan = item.optString("plan"),
                        createdAt = item.optLong("createdAt", System.currentTimeMillis())
                    ))
                }
            }
        } catch (_: Exception) { emptyList() }
    }

    private companion object {
        const val KEY_WORDS = "words_json"
        const val KEY_WRITINGS = "writings_json"
        const val KEY_PHRASES = "phrases_json"
        const val KEY_DAILY_GOAL = "daily_goal"
    }
}
